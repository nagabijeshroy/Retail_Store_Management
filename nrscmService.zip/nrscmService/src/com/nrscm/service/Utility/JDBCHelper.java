package com.nrscm.service.Utility;
import java.sql.*;

//import org.apache.log4j.Logger;

public class JDBCHelper {
	//static Logger log = Logger.getLogger(JDBCHelper.class);
	   static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	   static final String DB_URL = "jdbc:mysql://localhost:3306/nrscm";
	   static final String USER = "root";
	   static final String PASS = "";
	public static Connection connect(){
		Connection connection = null;
		   try{
			      //STEP 2: Register JDBC driver
			      Class.forName("com.mysql.jdbc.Driver");
	
			      //STEP 3: Open a connection
			      System.out.println("Connecting to database...");
			      connection = DriverManager.getConnection(DB_URL,USER,PASS);
			   }
			   catch(SQLException se){
			      //Handle errors for JDBC
			      se.printStackTrace();
			   }catch(Exception e){
			      //Handle errors for Class.forName
			      e.printStackTrace();
			   }
			   return  connection;
}

}