package com.nrscm.service.cps;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.nrscm.service.Bill;
import com.nrscm.service.Item;
import com.nrscm.tdgateway.BaseDataGateway;

public class BillTableDataGateway extends BaseDataGateway {
	
	// RAJU BEGINS
     public ResultSet getBill(Bill bill){
    	 String selectBillSQL="SELECT BILL_ID, BILL_AMOUNT,  DISCOUNT_AVAILED, OLD_BILL_REF, CARD_ID, BILL_DATE FROM BILL WHERE BILL_ID=? AND STORE_ID=?";
         try{
        	 PreparedStatement preparedStatement = getConnection().prepareStatement(selectBillSQL);
 			preparedStatement.setInt(1, bill.getBillId());
 			preparedStatement.setInt(2, bill.getStoreId());
 			ResultSet rs = preparedStatement.executeQuery();
 			return rs;
      }catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		return null;
	}
     
    public ResultSet getBillItems(Bill bill){
    	String selectBillSQL="SELECT B.ITEM_ID, I.ITEM_NAME, B.QUANTITY FROM BILLITEMS B, ITEM I  WHERE BILL_ID=? AND B.ITEM_ID=I.ITEM_ID";
    	try{
       	    PreparedStatement preparedStatement = getConnection().prepareStatement(selectBillSQL);
			preparedStatement.setInt(1, bill.getBillId());
			ResultSet rs = preparedStatement.executeQuery();
			return rs;
     }catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} 
		return null;
    }
     
    public boolean createBill(Bill billType){ 
    	if(billType.getOldBillRef()!=null){
    	String insertBillSQL= "INSERT INTO BILL (DISCOUNT_AVAILED, BILL_AMOUNT, OLD_BILL_REF, BILL_DATE, CARD_ID, STORE_ID) VALUES (?,?,?,?,?,?)";
    	 ResultSet generatedKeys=null;
    	 try {
 			PreparedStatement preparedStatement=getConnection().prepareStatement(insertBillSQL, Statement.RETURN_GENERATED_KEYS);
 			//preparedStatement.setInt(1, billType.getBillId());
 			//preparedStatement.setBillItems(2, billType.getBillItems());
 			preparedStatement.setBigDecimal(1, billType.getDiscountAvailed());
 			preparedStatement.setBigDecimal(2, billType.getBillAmount());
 			preparedStatement.setInt(3, billType.getOldBillRef().getBillId());
 			preparedStatement.setString(4, billType.getBillDate());
 			preparedStatement.setInt(5, billType.getCustomerCard().getCardNumber());
 			preparedStatement.setInt(6, billType.getStoreId());
 			preparedStatement.executeUpdate();			
 			generatedKeys = preparedStatement.getGeneratedKeys();
    	 } catch (SQLException e) {
 			System.out.println("Error in creating bill");
 			e.printStackTrace();
 			return false;
 		}finally{
 			try {
 				getConnection().close();
 			} catch (SQLException e) {
 				e.printStackTrace();
 			}
 		}
    	 if(generatedKeys!=null){
    		 int newBillId=0;
    		 try {
				if (generatedKeys.next()) {
					 newBillId = generatedKeys.getInt(1);
				 }
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	    	 for(Item i:billType.getBillItems().getBillItems()){
		    	 String insertBillItemsSQL= "INSERT INTO BILLITEMS (BILL_ID, ITEM_ID, QUANTITY, STORE_ID) VALUES (?,?,?,?)";
		    	 try{
		    		 PreparedStatement preparedStatement=getConnection().prepareStatement(insertBillItemsSQL);
		    		 preparedStatement.setInt(1, newBillId);
		    		 preparedStatement.setInt(2, i.getId());
		    		 preparedStatement.setBigDecimal(3, i.getQuantity());
		    		 preparedStatement.setInt(4, billType.getStoreId());
		    		 preparedStatement.executeUpdate();
		    	 }catch (SQLException e) {
		  			System.out.println("Error in inserting billitems");
		  			e.printStackTrace();
		  			return false;
		  		}finally{
		  			try {
		  				getConnection().close();
		  			} catch (SQLException e) {
		  				e.printStackTrace();
		  			}
		  		}  
	    	 }
    	 }
    	 return true;
    	}
    	else{
    		// handle if card id is present or not case
    		String insertBillSQL= "INSERT INTO BILL (DISCOUNT_AVAILED, BILL_AMOUNT, BILL_DATE, CARD_ID, STORE_ID) VALUES (?,?,?,?,?)";
       	 ResultSet generatedKeys=null;
       	 try {
    			PreparedStatement preparedStatement=getConnection().prepareStatement(insertBillSQL, Statement.RETURN_GENERATED_KEYS);
    			//preparedStatement.setInt(1, billType.getBillId());
    			//preparedStatement.setBillItems(2, billType.getBillItems());
    			preparedStatement.setBigDecimal(1, billType.getDiscountAvailed());
    			preparedStatement.setBigDecimal(2, billType.getBillAmount());
    			//preparedStatement.setInt(3, billType.getOldBillRef().getBillId());
    			preparedStatement.setString(3, billType.getBillDate());
    			preparedStatement.setInt(4, billType.getCustomerCard().getCardNumber());
    			preparedStatement.setInt(5, billType.getStoreId());
    			preparedStatement.executeUpdate();			
    			generatedKeys = preparedStatement.getGeneratedKeys();
       	 } catch (SQLException e) {
    			System.out.println("Error in creating bill");
    			e.printStackTrace();
    			return false;
    		}finally{
    			try {
    				getConnection().close();
    			} catch (SQLException e) {
    				e.printStackTrace();
    			}
    		}
       	 if(generatedKeys!=null){
       		 int newBillId=0;
       		 try {
   				if (generatedKeys.next()) {
   					 newBillId = generatedKeys.getInt(1);
   				 }
   			} catch (SQLException e1) {
   				// TODO Auto-generated catch block
   				e1.printStackTrace();
   			}
   	    	 for(Item i:billType.getBillItems().getBillItems()){
   		    	 String insertBillItemsSQL= "INSERT INTO BILLITEMS (BILL_ID, ITEM_ID, QUANTITY, STORE_ID) VALUES (?,?,?,?)";
   		    	 try{
   		    		 PreparedStatement preparedStatement=getConnection().prepareStatement(insertBillItemsSQL);
   		    		 preparedStatement.setInt(1, newBillId);
   		    		 preparedStatement.setInt(2, i.getId());
   		    		 preparedStatement.setBigDecimal(3, i.getQuantity());
   		    		 preparedStatement.setInt(4, billType.getStoreId());
   		    		 preparedStatement.executeUpdate();
   		    	 }catch (SQLException e) {
   		  			System.out.println("Error in inserting billitems");
   		  			e.printStackTrace();
   		  			return false;
   		  		}finally{
   		  			try {
   		  				getConnection().close();
   		  			} catch (SQLException e) {
   		  				e.printStackTrace();
   		  			}
   		  		}  
   	    	 }
       	 }
       	 return true;
    	}
 	}
    
    // RAJU ENDS
    
    // LAVANYA BEGINS
    
    /*public boolean createBill(Bill billType){	
		String insertItemSQL = "INSERT INTO BILL (BILLID, LISTITEMS, BILLAMOUNT, BILLDATE) VALUES (?, ?, ?, ?)";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(insertItemSQL);
			preparedStatement.setInt(1, billType.getBillId());
			//preparedStatement.setString(2, billType.getListitems());
			//System.out.println("ItemDataGateway "+itemType.getPricePerUnit());
			//preparedStatement.setDouble(3, itemType.getPricePerUnit());
			preparedStatement.setBigDecimal(3, billType.getBillAmount());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in inserting item");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}*/


	// LAVANYA ENDS

    
    
    
    
}
