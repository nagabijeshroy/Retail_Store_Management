package com.nrscm.service.pc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.nrscm.service.Clearance;
import com.nrscm.service.Item;
import com.nrscm.tdgateway.BaseDataGateway;

public class ClearanceDataGateway extends BaseDataGateway {
	
	public ResultSet createClearance(Clearance clearanceType){
		
		String insertClearanceSQL = "INSERT INTO CLEARANCE (CLEARANCE_NAME, CLEARANCE_DISCOUNT, STORE_ID) VALUES (?, ?, ?)";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(insertClearanceSQL, Statement.RETURN_GENERATED_KEYS);
			//preparedStatement.setInt(1, clearanceType.getId());
			preparedStatement.setString(1, clearanceType.getName());
			preparedStatement.setBigDecimal(2, clearanceType.getDiscount());
			preparedStatement.setInt(3, clearanceType.getStoreId());
			preparedStatement.executeUpdate();
			ResultSet rs=preparedStatement.getGeneratedKeys();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in inserting Clearance");
			e.printStackTrace();
			return null;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		//return true;
	}
	
	public ResultSet checkIfItemIsUnderClearance(Item item){
		String selectClearance = "SELECT CLEARANCE_ID FROM CLEARANCE_ITEM WHERE ITEM_ID=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(selectClearance);
			preparedStatement.setInt(1, item.getId());
			ResultSet rs=preparedStatement.executeQuery();
			return rs;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in selecting Clearance");
			e.printStackTrace();
			return null;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public boolean insertClearanceItems(Clearance clearance){
		String insertClearanceItemSQL = "INSERT INTO CLEARANCE_ITEM (CLEARANCE_ID, ITEM_ID, STORE_ID) VALUES (?, ?, ?)";
		try {
				PreparedStatement preparedStatement=getConnection().prepareStatement(insertClearanceItemSQL);
				for(Item item:clearance.getItems()){
					preparedStatement.setInt(1, clearance.getId());
					preparedStatement.setInt(2, item.getId());				
					preparedStatement.setInt(3, clearance.getStoreId());
					preparedStatement.executeUpdate();	
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in inserting Clearance Items");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public boolean updateClearance(Clearance clearanceType){
		
		String updateClearanceSQL = "UPDATE CLEARANCE SET CLEARANCE_NAME=?, CLEARANCE_DISCOUNT=? WHERE CLEARANCE_ID=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(updateClearanceSQL);
			preparedStatement.setString(1, clearanceType.getName());
			preparedStatement.setBigDecimal(2, clearanceType.getDiscount());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in updating Clearance");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public boolean removeClearance(Clearance clearance){
		String removeClearanceSQL = "DELETE FROM CLEARANCE WHERE CLEARANCE_ID=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(removeClearanceSQL);
			preparedStatement.setInt(1, clearance.getId());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in deleting clearance");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public ResultSet getClearanceForItem(Item item){
		String selectClearanceItemSQL="SELECT CI.ITEM_ID, CI.CLEARANCE_ID, C.CLEARANCE_NAME, C.CLEARANCE_DISCOUNT, C.STORE_ID FROM CLEARANCE C, CLEARANCE_ITEM CI WHERE CI.ITEM_ID=? AND CI.CLEARANCE_ID=C.CLEARANCE_ID";
		try{
			//String selectSQL = "SELECT USER_ID, USERNAME FROM DBUSER WHERE USER_ID = ?";
			PreparedStatement preparedStatement = getConnection().prepareStatement(selectClearanceItemSQL);
			preparedStatement.setInt(1, item.getId());
			ResultSet rs = preparedStatement.executeQuery();
			return rs;
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
}
	
	
