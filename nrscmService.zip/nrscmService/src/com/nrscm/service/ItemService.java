package com.nrscm.service;

import java.sql.ResultSet;
import java.util.List;
import javax.jws.WebService;
import com.nrscm.service.CreateItemRequest;
import com.nrscm.service.CreateItemResponse;
import com.nrscm.service.GetItemRequest;
import com.nrscm.service.GetItemResponse;
import com.nrscm.service.Item;
import com.nrscm.service.ItemServiceInterface;
import com.nrscm.service.Messages;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.item.ItemDataGateway;
import com.nrscm.service.item.ItemTableModule;

@WebService(name = "ItemServiceInterface", serviceName = "ItemServiceClient", endpointInterface = "com.nrscm.service.ItemServiceInterface", targetNamespace = "http://service.nrscm.com/", portName = "ItemServicePort", wsdlLocation = "/wsdl/item.wsdl")


public class ItemService implements ItemServiceInterface {

	@Override
	public CreateItemResponse createItem(CreateItemRequest parameters) {
		// TODO Auto-generated method stub
		System.out.println("************* createItem");
		Item item=parameters.getItem();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=ItemTableModule.vaidateForCreateItem(item, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			ItemDataGateway itemDataGateway=new ItemDataGateway();
			boolean inserted=itemDataGateway.createItem(item);
		}
		CreateItemResponse createItemResponseType=of.createCreateItemResponse();
		createItemResponseType.setItem(item);
		createItemResponseType.setValidationMessages(validationMessages);
		return createItemResponseType;
	}

	@Override
	public GetItemResponse getItem(GetItemRequest parameters) {
		// TODO Auto-generated method stub
		System.out.println("************* getItem");
		System.out.println(parameters.getItem().getId());
		Item item=parameters.getItem();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		//List<String> messageStrings=validationMessages.getMessages();
		//messageStrings=ItemTableModule.validateForGetItem(item);
		validationMessages=ItemTableModule.validateForGetItem(item, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			ItemDataGateway itemDataGateway=new ItemDataGateway();
			ResultSet rs=itemDataGateway.getItem(item);
			item=ItemTableModule.mapGetItemResultSetToItem(rs);
		}
		GetItemResponse getItemResponse=of.createGetItemResponse();
		getItemResponse.setItem(item);
		//getItemResponse.setStoreId(parameters.getStoreId());
		getItemResponse.setValidationMessages(validationMessages);
		return getItemResponse;
	}
	
	@Override
	public GetItemsResponse getItems(GetItemsRequest getItemsRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* getItems");
		// TODO Auto-generated method stub
		Item item=getItemsRequestMessage.getItem();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		GetItemsResponse getItemsResponse=of.createGetItemsResponse();
		getItemsResponse.setItems(of.createItems());
		Items items=getItemsResponse.getItems();
		ItemDataGateway itemDataGateway=new ItemDataGateway();
		ResultSet rs=itemDataGateway.getItems(item);
		items=ItemTableModule.mapGetItemsResultSetToItemList(rs, items);
		getItemsResponse.setItems(items);
		getItemsResponse.setValidationMessages(validationMessages);
		return getItemsResponse;
	}

	@Override
	public UpdateItemResponse updateItem(UpdateItemRequest updateItemRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* updateItem");
		Item item=updateItemRequestMessage.getItem();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		//List<String> messageStrings=validationMessages.getMessages();
		validationMessages=ItemTableModule.vaidateForUpdateItem(item, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			ItemDataGateway itemDataGateway=new ItemDataGateway();
			boolean inserted=itemDataGateway.updateItem(item);
		}
		UpdateItemResponse updateItemResponse=of.createUpdateItemResponse();
		updateItemResponse.setItem(item);
		updateItemResponse.setValidationMessages(validationMessages);
		return updateItemResponse;
	}

	@Override
	public DeleteItemResponse deleteItem(DeleteItemRequest deleteItemRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* deleteItem");
		Item item=deleteItemRequestMessage.getItem();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=ItemTableModule.vaidateForDeleteItem(item, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			ItemDataGateway itemDataGateway=new ItemDataGateway();
			boolean inserted=itemDataGateway.deleteItem(item);
		}
		DeleteItemResponse deleteItemResponse=of.createDeleteItemResponse();
		deleteItemResponse.setItem(item);
		deleteItemResponse.setValidationMessages(validationMessages);
		return deleteItemResponse;
	}
	
}
