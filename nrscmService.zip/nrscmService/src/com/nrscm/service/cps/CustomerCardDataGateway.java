package com.nrscm.service.cps;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.nrscm.service.CustomerCard;
import com.nrscm.tdgateway.BaseDataGateway;

public class CustomerCardDataGateway extends BaseDataGateway {
	
	// RAJU BEGINS
	public ResultSet getCardDetails(CustomerCard customercard){
		String selectCustomerCardSQL="SELECT CARD_ID, CUSTOMER_NAME, POINTS FROM CUSTOMERCARD WHERE CARD_ID=?";
        try{
        	PreparedStatement preparedStatement = getConnection().prepareStatement(selectCustomerCardSQL);
			preparedStatement.setInt(1, customercard.getCardNumber());
			ResultSet rs = preparedStatement.executeQuery();
			return rs;
        }catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
    }
    
    public boolean updateCardDetails(CustomerCard customercardType){
		
		String updateCardDetailsSQL = "UPDATE CUSTOMERCARD SET POINTS=POINTS + ? WHERE CARD_ID=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(updateCardDetailsSQL);
			preparedStatement.setInt(1, customercardType.getPoints());
			preparedStatement.setInt(2, customercardType.getCardNumber());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			System.out.println("Error in updating item");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return true;
	}
    
    // RAJU ENDS
    
    // LAVANYA BEGINS
    
    public ResultSet createCustomerCard(CustomerCard customerCardType){
    	ResultSet generatedKeys=null;
    	String insertCCSQL = "INSERT INTO CUSTOMERCARD (CUSTOMER_NAME,POINTS, STORE_ID) VALUES (?, ?, ?)";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(insertCCSQL, Statement.RETURN_GENERATED_KEYS);
			//preparedStatement.setInt(1, customerCardType.getCardNumber());
			preparedStatement.setString(1, customerCardType.getCustomerName());
			preparedStatement.setInt(2, customerCardType.getPoints());
			preparedStatement.setInt(3, customerCardType.getStoreId());
			preparedStatement.executeUpdate();
			generatedKeys = preparedStatement.getGeneratedKeys();
						
		} catch (SQLException e) {
			System.out.println("Error in inserting item");
			e.printStackTrace();
			//return null;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return generatedKeys;
	
	}

	public boolean updateCustomerCard(CustomerCard customerCardType){
		
		String updateItemSQL = "UPDATE StoreCard SET  CUSTOMERNAME=?, POINTS=?,  WHERE CARDNUMBER=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(updateItemSQL);
			preparedStatement.setString(1, customerCardType.getCustomerName());
			preparedStatement.setInt(2, customerCardType.getPoints());
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in updating item");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
    //LAVANYA ENDS
}