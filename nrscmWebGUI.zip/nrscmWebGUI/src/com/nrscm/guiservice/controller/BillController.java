package com.nrscm.guiservice.controller;

import com.google.gson.Gson;
import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.Bill;
import com.nrscm.service.CpsServiceInterface;
import com.nrscm.service.CreateNewBillRequest;
import com.nrscm.service.CreateNewBillResponse;
import com.nrscm.service.GetExistingBillRequest;
import com.nrscm.service.GetExistingBillResponse;
import com.nrscm.service.GetItemsRequest;
import com.nrscm.service.GetItemsResponse;
import com.nrscm.service.Item;
import com.nrscm.service.ItemServiceInterface;
import com.nrscm.service.ObjectFactory;

public class BillController {
	
	public String getExistingBill(String jsonBill){
		System.out.println("BillController "+jsonBill);
		jsonBill=jsonBill.substring(11, jsonBill.length()-1);
		System.out.println("BillController "+jsonBill);
		Gson gson=new Gson();
		Bill bill=gson.fromJson(jsonBill, Bill.class);
		CpsServiceInterface cpsServiceInterface=NRSCMClient.getCpsServiceInterface();
		ObjectFactory of=new ObjectFactory();
		GetExistingBillRequest getExistingBillRequest=of.createGetExistingBillRequest();
		getExistingBillRequest.setBill(bill);
		GetExistingBillResponse getExistingBillResponse=cpsServiceInterface.getExistingBill(getExistingBillRequest);
		String getExistingBillResponseJson=gson.toJson(getExistingBillResponse);
		return getExistingBillResponseJson;
	}
	
	public String generateNewBill(String jsonBill){
		System.out.println("BillController "+jsonBill);
		jsonBill=jsonBill.substring(11, jsonBill.length()-1);
		System.out.println("BillController "+jsonBill);
		Gson gson=new Gson();
		Bill bill=gson.fromJson(jsonBill, Bill.class);
		CpsServiceInterface cpsServiceInterface=NRSCMClient.getCpsServiceInterface();
		ObjectFactory of=new ObjectFactory();
		CreateNewBillRequest createNewBillRequest=of.createCreateNewBillRequest();
		createNewBillRequest.setBill(bill);
		CreateNewBillResponse createNewBillResponse=cpsServiceInterface.createNewBill(createNewBillRequest);
		String createNewBillResponseJson=gson.toJson(createNewBillResponse);
		return createNewBillResponseJson;
	}

}
