package com.nrscm.guiservice.controller;

import com.google.gson.Gson;
import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.AddPromotionRequest;
import com.nrscm.service.AddPromotionResponse;
import com.nrscm.service.GetPromotionForItemRequest;
import com.nrscm.service.GetPromotionForItemResponse;
import com.nrscm.service.Item;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.PCServiceInterface;
import com.nrscm.service.Promotion;
import com.nrscm.service.RemovePromotionRequest;
import com.nrscm.service.RemovePromotionResponse;
import com.nrscm.service.UpdatePromotionRequest;
import com.nrscm.service.UpdatePromotionResponse;

public class PromotionController {
	
	public String getPromotionForItem(String jsonItem){
		System.out.println("PromotionController "+jsonItem);
		//jsonItem=jsonItem.substring(11, jsonItem.length()-1);
		System.out.println("PromotionController "+jsonItem);
		Gson gson=new Gson();
		Item item=gson.fromJson(jsonItem, Item.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		GetPromotionForItemRequest getPromotionForItemRequest=of.createGetPromotionForItemRequest();
		getPromotionForItemRequest.setItem(item);
		GetPromotionForItemResponse getPromotionForItemResponse=pcServiceInterface.getPromotionForItem(getPromotionForItemRequest);
		String getPromotionForItemResponseJson=gson.toJson(getPromotionForItemResponse);
		return getPromotionForItemResponseJson;
	}
	
	public String addPromotion(String jsonPromotion){
		System.out.println("PromotionController "+jsonPromotion);
		jsonPromotion=jsonPromotion.substring(16, jsonPromotion.length()-1);
		System.out.println("PromotionController "+jsonPromotion);
		Gson gson=new Gson();
		Promotion promotion=gson.fromJson(jsonPromotion, Promotion.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		AddPromotionRequest addPromotionRequest=of.createAddPromotionRequest();
		addPromotionRequest.setPromotion(promotion);
		AddPromotionResponse addPromotionResponse=pcServiceInterface.addPromotion(addPromotionRequest);
		String addPromotionResponseJson=gson.toJson(addPromotionResponse);
		return addPromotionResponseJson;
	}
	
	public String updatePromotion(String jsonPromotion){
		System.out.println("PromotionController "+jsonPromotion);
		jsonPromotion=jsonPromotion.substring(16, jsonPromotion.length()-1);
		System.out.println("PromotionController "+jsonPromotion);
		Gson gson=new Gson();
		Promotion promotion=gson.fromJson(jsonPromotion, Promotion.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		UpdatePromotionRequest updatePromotionRequest=of.createUpdatePromotionRequest();
		updatePromotionRequest.setPromotion(promotion);
		UpdatePromotionResponse updatePromotionResponse=pcServiceInterface.updatePromotion(updatePromotionRequest);
		String updatePromotionResponseJson=gson.toJson(updatePromotionResponse);
		return updatePromotionResponseJson;
	}
	
	public String removePromotion(String jsonPromotion){
		System.out.println("PromotionController "+jsonPromotion);
		jsonPromotion=jsonPromotion.substring(16, jsonPromotion.length()-1);
		System.out.println("PromotionController "+jsonPromotion);
		Gson gson=new Gson();
		Promotion promotion=gson.fromJson(jsonPromotion, Promotion.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		RemovePromotionRequest removePromotionRequest=of.createRemovePromotionRequest();
		removePromotionRequest.setPromotion(promotion);
		RemovePromotionResponse removePromotionResponse=pcServiceInterface.removePromotion(removePromotionRequest);
		String removePromotionResponseJson=gson.toJson(removePromotionResponse);
		return removePromotionResponseJson;
	}

}
