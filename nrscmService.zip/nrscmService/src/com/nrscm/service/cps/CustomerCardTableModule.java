package com.nrscm.service.cps;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.nrscm.service.CustomerCard;
import com.nrscm.service.Messages;
import com.nrscm.service.ObjectFactory;

public class CustomerCardTableModule {

	// RAJU BEGINS
	public static Messages validateForGetCardDetails(CustomerCard customercard,Messages valMessages)
	{
		List<String> validationMessages=valMessages.getMessages();
		if(customercard.getCardNumber()==null){
			validationMessages.add("Need Card Number");
			System.out.println("Need Card Number");
		}
		return valMessages;
	}
	public static Messages validateForUpdateCardDetails(CustomerCard customercard,Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(customercard.getCardNumber()==null){
			validationMessages.add("Need Customer Card Number");
			System.out.println("Need Customer Card Number");
		}
		/*if(customercard.getCustomerName()==null){
			validationMessages.add("Need Customer Name");
			System.out.println("Need Customer Name");
		}*/
		if(customercard.getPoints()==null){
			validationMessages.add("Need Customer Card Points");
			System.out.println("Need Customer Card Points");
		}
        return valMessages;
	   }
	public static CustomerCard mapGetCustomerCardResultSetToCustomerCard(ResultSet rs){
		ObjectFactory of=new ObjectFactory();
		CustomerCard customercard=of.createCustomerCard();
		try{ 
			if(rs.next()){
				customercard.setCardNumber(rs.getInt("CARD_ID"));
				customercard.setCustomerName(rs.getString("CUSTOMER_NAME"));
				customercard.setPoints(rs.getInt("POINTS"));
				return customercard;
			}
		}catch(SQLException e){
				System.out.println("CustomerCardTableModule: SQL Exception");
				e.printStackTrace();
		}
         return null;   
	}	
	
    // RAJU ENDS
	
	// LAVANYA BEGINS
	
	public static Messages validateForCreateCustomerCard(CustomerCard customerCard, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		
		if(customerCard.getCustomerName()==null){
			validationMessages.add("Need Customer Name");
			System.out.println("Need Customer Name");
		}
		
		if(customerCard.getStoreId()==null){
			validationMessages.add("Store Id needed");
			System.out.println("Store Id needed");
		}
		return valMessages;

	}
	
	public static Messages validateForupdateStoreCard(CustomerCard customerCard, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(customerCard.getCardNumber()==null){
			validationMessages.add("Need card number");
			System.out.println("Need card number");
		}
		if(customerCard.getCustomerName()==null){
			validationMessages.add("Need customerName");
			System.out.println("Need customerName");
		}
		if(customerCard.getPoints()==null){
			validationMessages.add("points needed");
			System.out.println("points needed");
		}
		
			return valMessages;

	}
	
	
	// LAVANYA ENDS
}
   