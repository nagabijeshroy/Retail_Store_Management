package com.nrscm.tdgateway;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class BaseDataGateway {
	
	private Connection conn;
	
	public Connection getConnection(){
		try {
			Class.forName("com.mysql.jdbc.Driver");
			conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/nrscm", "root", "");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Couldn't connect to DB");
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Couldn't find driver");
			e.printStackTrace();
		}
		return conn;
	}
	
	
	
	
}
