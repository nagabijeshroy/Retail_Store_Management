package com.nrscm.service.TableModule;

import com.nrscm.service.Messages;
import com.nrscm.service.Store;

public class StoreTableModule {

	public static Messages validateStoreDetails(Store store, Messages messages) {
		Messages messages2 = new Messages();
		messages2.getMessages().add("Success");
		return messages2;
	}

}
