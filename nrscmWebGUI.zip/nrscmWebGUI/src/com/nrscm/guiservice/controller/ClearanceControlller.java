package com.nrscm.guiservice.controller;

import com.google.gson.Gson;
import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.AddClearanceRequest;
import com.nrscm.service.AddClearanceResponse;
import com.nrscm.service.Clearance;
import com.nrscm.service.GetClearanceForItemRequest;
import com.nrscm.service.GetClearanceForItemResponse;
import com.nrscm.service.Item;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.PCServiceInterface;
import com.nrscm.service.RemoveClearanceRequest;
import com.nrscm.service.RemoveClearanceResponse;
import com.nrscm.service.UpdateClearanceRequest;
import com.nrscm.service.UpdateClearanceResponse;

public class ClearanceControlller {

	public String getClearanceForItem(String jsonItem){
		System.out.println("ClearanceControlller "+jsonItem);
		//jsonItem=jsonItem.substring(11, jsonItem.length()-1);
		System.out.println("ClearanceControlller "+jsonItem);
		Gson gson=new Gson();
		Item item=gson.fromJson(jsonItem, Item.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		GetClearanceForItemRequest getClearanceForItemRequest=of.createGetClearanceForItemRequest();
		getClearanceForItemRequest.setItem(item);
		GetClearanceForItemResponse getClearanceForItemResponse=pcServiceInterface.getClearanceForItem(getClearanceForItemRequest);
		String getClearanceForItemResponseJson=gson.toJson(getClearanceForItemResponse);
		return getClearanceForItemResponseJson;
	}
	
	public String createClearance(String jsonClearance){
		System.out.println("ClearanceControlller "+jsonClearance);
		jsonClearance=jsonClearance.substring(16, jsonClearance.length()-1);
		System.out.println("ClearanceControlller "+jsonClearance);
		Gson gson=new Gson();
		Clearance clearance=gson.fromJson(jsonClearance, Clearance.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		AddClearanceRequest addClearanceRequest=of.createAddClearanceRequest();
		addClearanceRequest.setClearance(clearance);
		AddClearanceResponse addClearanceResponse=pcServiceInterface.addClearance(addClearanceRequest);
		String addClearanceResponseJson=gson.toJson(addClearanceResponse);
		return addClearanceResponseJson;
	}
	
	public String updateClearance(String jsonClearance){
		System.out.println("ClearanceControlller "+jsonClearance);
		jsonClearance=jsonClearance.substring(16, jsonClearance.length()-1);
		System.out.println("ClearanceControlller "+jsonClearance);
		Gson gson=new Gson();
		Clearance clearance=gson.fromJson(jsonClearance, Clearance.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		UpdateClearanceRequest updateClearanceRequest=of.createUpdateClearanceRequest();
		updateClearanceRequest.setClearance(clearance);
		UpdateClearanceResponse updateClearanceResponse=pcServiceInterface.updateClearance(updateClearanceRequest);
		String updateClearanceResponseJson=gson.toJson(updateClearanceResponse);
		return updateClearanceResponseJson;
	}
	
	public String removeClearance(String jsonClearance){
		System.out.println("ClearanceControlller "+jsonClearance);
		jsonClearance=jsonClearance.substring(16, jsonClearance.length()-1);
		System.out.println("ClearanceControlller "+jsonClearance);
		Gson gson=new Gson();
		Clearance clearance=gson.fromJson(jsonClearance, Clearance.class);
		PCServiceInterface pcServiceInterface=NRSCMClient.getPCServiceInterface();
		ObjectFactory of=new ObjectFactory();
		RemoveClearanceRequest removeClearanceRequest=of.createRemoveClearanceRequest();
		removeClearanceRequest.setClearance(clearance);
		RemoveClearanceResponse removeClearanceResponse=pcServiceInterface.removeClearance(removeClearanceRequest);
		String removeClearanceResponseJson=gson.toJson(removeClearanceResponse);
		return removeClearanceResponseJson;
	}
	
}
