package com.nrscm.guiservice.controller;

import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.AddStoreRequest;
import com.nrscm.service.AddStoreResponse;
import com.nrscm.service.CNSServiceInterface;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.Store;
import com.nrscm.service.StoreDetails;
import com.nrscm.service.UpdateStoreRequest;
import com.nrscm.service.UpdateStoreResponse;
import com.nrscm.service.ViewStoreListRequest;
import com.nrscm.service.ViewStoreListResponse;

public class StoreController {
	CNSServiceInterface cnsServiceInterface = NRSCMClient.getCNSServiceInterface();
	ObjectFactory objectFactory = new ObjectFactory();
	public AddStoreResponse addStoreDetails(Store store) {
		AddStoreRequest addStoreRequest = objectFactory.createAddStoreRequest();
		addStoreRequest.setStore(store);
		System.out.println("Add Store");
		AddStoreResponse addStoreResponse = cnsServiceInterface.addStoreDetails(addStoreRequest);
		return addStoreResponse;
	}
	public String authenticateLogin(String jsonItem) {
		return "Bijesh";
	}
	public StoreDetails viewStoreList() {
		ViewStoreListRequest viewStoreListRequest = objectFactory.createViewStoreListRequest();
		ViewStoreListResponse viewStoreListResponse = cnsServiceInterface.viewStoreList(viewStoreListRequest);
		return viewStoreListResponse.getStoreDetails();
	}
	public UpdateStoreResponse updateStoreDetails(Store store) {
		UpdateStoreRequest updateStoreRequest = objectFactory.createUpdateStoreRequest();
		UpdateStoreResponse updateStoreResponse = cnsServiceInterface.updateStore(updateStoreRequest);
		return updateStoreResponse;
	}

}
