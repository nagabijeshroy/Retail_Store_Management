package com.nrscm.service.item;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nrscm.service.Item;
import com.nrscm.tdgateway.BaseDataGateway;

public class ItemDataGateway extends BaseDataGateway {
	
	public boolean createItem(Item itemType){
		
		String insertItemSQL = "INSERT INTO ITEM (ITEM_NAME, ITEM_PPU, ITEM_QUANTITY, DEPT_ID, LAST_UPDATED_BY, STORE_ID) VALUES (?, ?, ?, ?, ?, ?)";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(insertItemSQL);
			//preparedStatement.setInt(1, itemType.getId());
			preparedStatement.setString(1, itemType.getName());
			//System.out.println("ItemDataGateway "+itemType.getPricePerUnit());
			//preparedStatement.setDouble(3, itemType.getPricePerUnit());
			preparedStatement.setBigDecimal(2, itemType.getPricePerUnit());
			preparedStatement.setBigDecimal(3, itemType.getQuantity());
			preparedStatement.setInt(4, itemType.getDepartment().getId());
			preparedStatement.setInt(5, itemType.getLastUpdatedBy().getEid());
			preparedStatement.setInt(6, itemType.getStoreId());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in inserting item");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public boolean updateItem(Item itemType){
		if(itemType.getDepartment()!=null){
			String updateItemSQL = "UPDATE ITEM SET ITEM_NAME=?, ITEM_PPU=?, ITEM_QUANTITY=?, DEPT_ID=?, LAST_UPDATED_BY=? WHERE ITEM_ID=?";
			try {
				PreparedStatement preparedStatement=getConnection().prepareStatement(updateItemSQL);
				preparedStatement.setString(1, itemType.getName());
				//System.out.println("ItemDataGateway "+itemType.getPricePerUnit());
				//preparedStatement.setDouble(3, itemType.getPricePerUnit());
				preparedStatement.setBigDecimal(2, itemType.getPricePerUnit());
				preparedStatement.setBigDecimal(3, itemType.getQuantity());
				preparedStatement.setInt(4, itemType.getDepartment().getId());
				preparedStatement.setInt(5, itemType.getLastUpdatedBy().getEid());
				preparedStatement.setInt(6, itemType.getId());
				preparedStatement.executeUpdate();			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Error in updating item");
				e.printStackTrace();
				return false;
			}finally{
				try {
					getConnection().close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return true;
		}
		else{
			String updateItemSQL = "UPDATE ITEM SET ITEM_QUANTITY=ITEM_QUANTITY-? WHERE ITEM_ID=?";
			try {
				PreparedStatement preparedStatement=getConnection().prepareStatement(updateItemSQL);
				//preparedStatement.setString(1, itemType.getName());
				//System.out.println("ItemDataGateway "+itemType.getPricePerUnit());
				//preparedStatement.setDouble(3, itemType.getPricePerUnit());
				//preparedStatement.setBigDecimal(2, itemType.getPricePerUnit());
				preparedStatement.setBigDecimal(1, itemType.getQuantity());
				//preparedStatement.setInt(4, itemType.getDepartment().getId());
				//preparedStatement.setInt(5, itemType.getLastUpdatedBy().getId());
				preparedStatement.setInt(2, itemType.getId());
				preparedStatement.executeUpdate();			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Error in updating item");
				e.printStackTrace();
				return false;
			}finally{
				try {
					getConnection().close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return true;
		}
	}
	
	public boolean deleteItem(Item item){
		String deleteItemSQL = "DELETE FROM ITEM WHERE ITEM_ID=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(deleteItemSQL);
			preparedStatement.setInt(1, item.getId());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in deleting item");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public ResultSet getItem(Item item){
		String selectItemSQL="SELECT ITEM_ID, ITEM_NAME, ITEM_PPU, ITEM_QUANTITY, DEPT_ID, LAST_UPDATED_BY FROM ITEM WHERE ITEM_ID=?";
		try{
			//String selectSQL = "SELECT USER_ID, USERNAME FROM DBUSER WHERE USER_ID = ?";
			PreparedStatement preparedStatement = getConnection().prepareStatement(selectItemSQL);
			preparedStatement.setInt(1, item.getId());
			ResultSet rs = preparedStatement.executeQuery();
			return rs;
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public ResultSet getItems(Item item){
		String selectItemSQL=null;
		PreparedStatement preparedStatement=null;
		try{
			if(item.getId()!=null){
				selectItemSQL="SELECT ITEM_ID, ITEM_NAME, ITEM_PPU, ITEM_QUANTITY, DEPT_ID, LAST_UPDATED_BY FROM ITEM WHERE ITEM_ID=?";
				preparedStatement = getConnection().prepareStatement(selectItemSQL);
				preparedStatement.setInt(1, item.getId());
			}
			else if(item.getId()==null&&!(item.getName()==null)){
				selectItemSQL="SELECT ITEM_ID, ITEM_NAME, ITEM_PPU, ITEM_QUANTITY, DEPT_ID, LAST_UPDATED_BY FROM ITEM WHERE ITEM_NAME LIKE '%?%'";
				preparedStatement = getConnection().prepareStatement(selectItemSQL);
				preparedStatement.setString(1, item.getName());
			}
			else{
				selectItemSQL="SELECT ITEM_ID, ITEM_NAME, ITEM_PPU, ITEM_QUANTITY, DEPT_ID, LAST_UPDATED_BY FROM ITEM";
				preparedStatement = getConnection().prepareStatement(selectItemSQL);
			}
			ResultSet rs = preparedStatement.executeQuery(selectItemSQL);
			return rs;
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}

}
