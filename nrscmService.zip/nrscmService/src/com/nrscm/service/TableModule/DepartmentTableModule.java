package com.nrscm.service.TableModule;

import com.nrscm.service.Department;
import com.nrscm.service.Messages;

public class DepartmentTableModule {

	public static Messages validateDepartmentDetails(Department department, Messages messages) {
		Messages messages2 = new Messages();
		messages2.getMessages().add("Success");
		return messages2;
	}

}
