package com.nrscm.guiservice;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/ui")
public class BaseApplication extends Application{
	
}
