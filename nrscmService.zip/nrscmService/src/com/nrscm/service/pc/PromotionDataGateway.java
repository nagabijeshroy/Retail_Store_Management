package com.nrscm.service.pc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nrscm.service.Item;
import com.nrscm.service.Promotion;
import com.nrscm.tdgateway.BaseDataGateway;

public class PromotionDataGateway extends BaseDataGateway {
	
	public boolean createPromotion(Promotion promotionType){
		
		String insertPromotionSQL = "INSERT INTO PROMOTION (DISCOUNTPERCENT, ITEM_ID) VALUES (?, ?)";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(insertPromotionSQL);
			preparedStatement.setBigDecimal(1, promotionType.getDiscount());
			preparedStatement.setInt(2, promotionType.getItemid());	
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in inserting Promotion");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public boolean updatePromotion(Promotion promotionType){
		
		String updatePromotionSQL = "UPDATE PROMOTION SET DISCOUNTPERCENT=? WHERE PROMOTION_ID=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(updatePromotionSQL);
			preparedStatement.setBigDecimal(1, promotionType.getDiscount());
			preparedStatement.setInt(2, promotionType.getId());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in updating Promotion");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public boolean removePromotion(Promotion promotion){
		String removePromotionSQL = "DELETE FROM PROMOTION WHERE PROMOTION_ID=?";
		try {
			PreparedStatement preparedStatement=getConnection().prepareStatement(removePromotionSQL);
			preparedStatement.setInt(1, promotion.getId());
			preparedStatement.executeUpdate();			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Error in deleting promotion");
			e.printStackTrace();
			return false;
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return true;
	}
	
	public ResultSet getPromotionForItem(Item item){
		String selectPromotionItemSQL="SELECT ITEM_ID, DISCOUNTPERCENT, PROMOTION_ID, STORE_ID FROM PROMOTION WHERE ITEM_ID=?";
		try{
			//String selectSQL = "SELECT USER_ID, USERNAME FROM DBUSER WHERE USER_ID = ?";
			PreparedStatement preparedStatement = getConnection().prepareStatement(selectPromotionItemSQL);
			preparedStatement.setInt(1, item.getId());
			ResultSet rs = preparedStatement.executeQuery();
			return rs;
		}catch(SQLException e){
			e.printStackTrace();
		}finally{
			try {
				getConnection().close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return null;
	}
	
	
}
	
	