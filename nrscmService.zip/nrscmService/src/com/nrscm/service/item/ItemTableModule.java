package com.nrscm.service.item;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nrscm.service.Department;
import com.nrscm.service.Employee;
import com.nrscm.service.Item;
import com.nrscm.service.Items;
import com.nrscm.service.Messages;
import com.nrscm.service.ObjectFactory;

public class ItemTableModule {

	
	public static Messages vaidateForCreateItem(Item item, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		/*if(item.getId()==null){
			validationMessages.add("Need id for item");
			System.out.println("Need id for item");
		}*/
		if(item.getDepartment()==null){
			validationMessages.add("Need department for item");
			System.out.println("Need department for item");
		}
		if(item.getDepartment()!=null&&item.getDepartment().getId()==null){
			validationMessages.add("Need department for item");
			System.out.println("Need department for item");
		}
		if(item.getLastUpdatedBy()==null){
			validationMessages.add("Need Last updated by Employee for item");
			System.out.println("Need Last updated by Employee for item");
		}
		if(item.getLastUpdatedBy()!=null&&item.getLastUpdatedBy().getEid()==null){
			validationMessages.add("Need Last updated by Employee for item");
			System.out.println("Need Last updated by Employee for item");
		}
		if(item.getName()==null){
			validationMessages.add("Item name missing");
			System.out.println("Item name missing");
		}
		if(item.getPricePerUnit()==null){
			validationMessages.add("Item price missing");
			System.out.println("Item price missing");
		}
		if(item.getQuantity()==null){
			validationMessages.add("Item quantity missing");
			System.out.println("Item quantity missing");
		}
		return valMessages;
	}
	
	public static Messages vaidateForUpdateItem(Item item, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(item.getId()==null){
			validationMessages.add("Need id for item");
			System.out.println("Need id for item");
		}
		if(item.getDepartment()==null){
			validationMessages.add("Need department for item");
			System.out.println("Need department for item");
		}
		if(item.getDepartment()!=null&&item.getDepartment().getId()==null){
			validationMessages.add("Need department for item");
			System.out.println("Need department for item");
		}
		if(item.getLastUpdatedBy()==null){
			validationMessages.add("Need Last updated by Employee for item");
			System.out.println("Need Last updated by Employee for item");
		}
		if(item.getLastUpdatedBy()!=null&&item.getLastUpdatedBy().getEid()==null){
			validationMessages.add("Need Last updated by Employee for item");
			System.out.println("Need Last updated by Employee for item");
		}
		if(item.getName()==null){
			validationMessages.add("Item name missing");
			System.out.println("Item name missing");
		}
		if(item.getPricePerUnit()==null){
			validationMessages.add("Item price missing");
			System.out.println("Item price missing");
		}
		if(item.getQuantity()==null){
			validationMessages.add("Item quantity missing");
			System.out.println("Item quantity missing");
		}
		return valMessages;
	}
	
	public static Messages vaidateForUpdateItemForPOS(Item item, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(item.getId()==null){
			validationMessages.add("Need id for item");
			System.out.println("Need id for item");
		}
		if(item.getQuantity()==null){
			validationMessages.add("Item quantity missing");
			System.out.println("Item quantity missing");
		}
		return valMessages;
	}
	
	public static Messages vaidateForDeleteItem(Item item, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(item.getId()==null){
			validationMessages.add("Need id for item");
			System.out.println("Need id for item");
		}
		return valMessages;
	}
	
	public static Messages validateForGetItem(Item item, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(item.getId()==null){
			System.out.println("Need item id");
			validationMessages.add("Need item id");
		}
		return valMessages;
	}
	
	public static List<String> validateForGetItems(Item item){
		List<String> validationMessages=new ArrayList<String>();
		if(item.getName()==null){
			validationMessages.add("Need item name");
		}
		return validationMessages;
	}
	
	public static Item mapGetItemResultSetToItem(ResultSet rs){
		ObjectFactory of=new ObjectFactory();
		Item item=of.createItem();
		
		try{
			if(rs.next()){
				Department dept=of.createDepartment();
				dept.setId(rs.getInt("DEPT_ID"));
				item.setDepartment(dept);
				item.setId(rs.getInt("ITEM_ID"));
				Employee emp=of.createEmployee();
				emp.setEid(rs.getInt("LAST_UPDATED_BY"));
				item.setLastUpdatedBy(emp);
				item.setName(rs.getString("ITEM_NAME"));
				item.setPricePerUnit(rs.getBigDecimal("ITEM_PPU"));
				item.setQuantity(rs.getBigDecimal("ITEM_QUANTITY"));
				return item;
			}
		}catch(SQLException e){
			System.out.println("ItemTableModule: SQL Exception");
			e.printStackTrace();
		}
		return null;
	}
	
	public static Items mapGetItemsResultSetToItemList(ResultSet rs, Items items){
		ObjectFactory of=new ObjectFactory();
		List<Item> itemList=items.getItems();
		try{
			while(rs.next()){	
				Item item=of.createItem();
				Department dept=of.createDepartment();
				dept.setId(rs.getInt("DEPT_ID"));
				item.setDepartment(dept);
				item.setId(rs.getInt("ITEM_ID"));
				Employee emp=of.createEmployee();
				emp.setEid(rs.getInt("LAST_UPDATED_BY"));
				item.setLastUpdatedBy(emp);
				item.setName(rs.getString("ITEM_NAME"));
				item.setPricePerUnit(rs.getBigDecimal("ITEM_PPU"));
				item.setQuantity(rs.getBigDecimal("ITEM_QUANTITY"));
				itemList.add(item);
			}
			return items;
		}catch(SQLException e){
			System.out.println("ItemTableModule: SQL Exception");
			e.printStackTrace();
		}
		return null;
	}
	
	
	
}
