
package com.nrscm.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Store complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Store">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="location" type="{http://service.nrscm.com/}StoreLocation" minOccurs="0"/>
 *         &lt;element name="storeName" type="{http://service.nrscm.com/}StoreName" minOccurs="0"/>
 *         &lt;element name="storeId" type="{http://service.nrscm.com/}StoreId" minOccurs="0"/>
 *         &lt;element name="storeHead" type="{http://service.nrscm.com/}StoreHead" minOccurs="0"/>
 *         &lt;element name="storeDB" type="{http://service.nrscm.com/}StoreDB" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Store", propOrder = {
    "location",
    "storeName",
    "storeId",
    "storeHead",
    "storeDB"
})
public class Store {

    protected String location;
    protected String storeName;
    protected Integer storeId;
    protected String storeHead;
    protected String storeDB;

    /**
     * Gets the value of the location property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocation() {
        return location;
    }

    /**
     * Sets the value of the location property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocation(String value) {
        this.location = value;
    }

    /**
     * Gets the value of the storeName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoreName() {
        return storeName;
    }

    /**
     * Sets the value of the storeName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoreName(String value) {
        this.storeName = value;
    }

    /**
     * Gets the value of the storeId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStoreId() {
        return storeId;
    }

    /**
     * Sets the value of the storeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStoreId(Integer value) {
        this.storeId = value;
    }

    /**
     * Gets the value of the storeHead property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoreHead() {
        return storeHead;
    }

    /**
     * Sets the value of the storeHead property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoreHead(String value) {
        this.storeHead = value;
    }

    /**
     * Gets the value of the storeDB property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStoreDB() {
        return storeDB;
    }

    /**
     * Sets the value of the storeDB property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStoreDB(String value) {
        this.storeDB = value;
    }

}
