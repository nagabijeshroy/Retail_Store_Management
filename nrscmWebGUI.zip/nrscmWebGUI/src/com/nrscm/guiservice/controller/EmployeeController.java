package com.nrscm.guiservice.controller;

import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.AddEmployeeRequest;
import com.nrscm.service.AddEmployeeResponse;
import com.nrscm.service.CNSServiceInterface;
import com.nrscm.service.DeleteEmployeeRequest;
import com.nrscm.service.DeleteEmployeeResponse;
import com.nrscm.service.Employee;
import com.nrscm.service.EmployeeDetails;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.SearchEmployeeRequest;
import com.nrscm.service.SearchEmployeeResponse;
import com.nrscm.service.UpdateEmployeeRequest;
import com.nrscm.service.UpdateEmployeeResponse;
import com.nrscm.service.ViewEmployeeRequest;
import com.nrscm.service.ViewEmployeeResponse;

public class EmployeeController {
	CNSServiceInterface cnsServiceInterface = NRSCMClient.getCNSServiceInterface();
	ObjectFactory objectFactory = new ObjectFactory();
	public AddEmployeeResponse addEmployee(Employee employee) {
		AddEmployeeRequest addEmployeeRequest = objectFactory.createAddEmployeeRequest();
		addEmployeeRequest.setEmployee(employee);
		AddEmployeeResponse addEmployeeResponse = cnsServiceInterface.addEmployee(addEmployeeRequest);
		return addEmployeeResponse;
	}
	public SearchEmployeeResponse searchEmployee(Employee employee) {
		SearchEmployeeRequest searchEmployeeRequest = objectFactory.createSearchEmployeeRequest();
		searchEmployeeRequest.setEmployee(employee);
		SearchEmployeeResponse searchEmployeeResponse = cnsServiceInterface.searchEmployee(searchEmployeeRequest);
		return searchEmployeeResponse;	}
	public UpdateEmployeeResponse updateEmployee(Employee employee) {
		UpdateEmployeeRequest updateEmployeeRequest = objectFactory.createUpdateEmployeeRequest();
		updateEmployeeRequest.setEmployee(employee);
		UpdateEmployeeResponse updateEmployeeResponse = cnsServiceInterface.updateEmployee(updateEmployeeRequest);
		return updateEmployeeResponse;
	}
	public DeleteEmployeeResponse deleteEmployee(Employee employee) {
		DeleteEmployeeRequest deleteEmployeeRequest = objectFactory.createDeleteEmployeeRequest();
		deleteEmployeeRequest.setEmployee(employee);
		DeleteEmployeeResponse deleteEmployeeResponse = cnsServiceInterface.deleteEmployee(deleteEmployeeRequest);
		return deleteEmployeeResponse;
	}
	public ViewEmployeeResponse viewEmployee() {
		ViewEmployeeRequest employeeRequest = objectFactory.createViewEmployeeRequest();
		ViewEmployeeResponse employeeResponse = cnsServiceInterface.viewEmployee(employeeRequest);
		return employeeResponse;
	}

}
