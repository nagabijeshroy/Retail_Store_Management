
package com.nrscm.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="departmentDetails" type="{http://service.nrscm.com/}DepartmentDetails"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "departmentDetails"
})
@XmlRootElement(name = "viewDepartmentListResponse")
public class ViewDepartmentListResponse {

    @XmlElement(required = true)
    protected DepartmentDetails departmentDetails;

    /**
     * Gets the value of the departmentDetails property.
     * 
     * @return
     *     possible object is
     *     {@link DepartmentDetails }
     *     
     */
    public DepartmentDetails getDepartmentDetails() {
        return departmentDetails;
    }

    /**
     * Sets the value of the departmentDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link DepartmentDetails }
     *     
     */
    public void setDepartmentDetails(DepartmentDetails value) {
        this.departmentDetails = value;
    }

}
