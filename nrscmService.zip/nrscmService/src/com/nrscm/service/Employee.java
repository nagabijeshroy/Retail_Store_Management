
package com.nrscm.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Employee complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Employee">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="Eid" type="{http://service.nrscm.com/}EmployeeId" minOccurs="0"/>
 *         &lt;element name="name" type="{http://service.nrscm.com/}EmployeeName" minOccurs="0"/>
 *         &lt;element name="storeId" type="{http://service.nrscm.com/}StoreId" minOccurs="0"/>
 *         &lt;element name="employeeAddress" type="{http://service.nrscm.com/}EmployeeAddress" minOccurs="0"/>
 *         &lt;element name="employeeDesgnation" type="{http://service.nrscm.com/}EmployeeDesignation" minOccurs="0"/>
 *         &lt;element name="isDepartmentHead" type="{http://service.nrscm.com/}IsDepartmentHead" minOccurs="0"/>
 *         &lt;element name="isStoreHead" type="{http://service.nrscm.com/}IsStoretHead" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Employee", propOrder = {
    "eid",
    "name",
    "storeId",
    "employeeAddress",
    "employeeDesgnation",
    "isDepartmentHead",
    "isStoreHead"
})
public class Employee {

    @XmlElement(name = "Eid")
    protected Integer eid;
    protected String name;
    protected Integer storeId;
    protected String employeeAddress;
    protected String employeeDesgnation;
    protected Boolean isDepartmentHead;
    protected Boolean isStoreHead;

    /**
     * Gets the value of the eid property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getEid() {
        return eid;
    }

    /**
     * Sets the value of the eid property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setEid(Integer value) {
        this.eid = value;
    }

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setName(String value) {
        this.name = value;
    }

    /**
     * Gets the value of the storeId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStoreId() {
        return storeId;
    }

    /**
     * Sets the value of the storeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStoreId(Integer value) {
        this.storeId = value;
    }

    /**
     * Gets the value of the employeeAddress property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeAddress() {
        return employeeAddress;
    }

    /**
     * Sets the value of the employeeAddress property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeAddress(String value) {
        this.employeeAddress = value;
    }

    /**
     * Gets the value of the employeeDesgnation property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeDesgnation() {
        return employeeDesgnation;
    }

    /**
     * Sets the value of the employeeDesgnation property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeDesgnation(String value) {
        this.employeeDesgnation = value;
    }

    /**
     * Gets the value of the isDepartmentHead property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsDepartmentHead() {
        return isDepartmentHead;
    }

    /**
     * Sets the value of the isDepartmentHead property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsDepartmentHead(Boolean value) {
        this.isDepartmentHead = value;
    }

    /**
     * Gets the value of the isStoreHead property.
     * 
     * @return
     *     possible object is
     *     {@link Boolean }
     *     
     */
    public Boolean isIsStoreHead() {
        return isStoreHead;
    }

    /**
     * Sets the value of the isStoreHead property.
     * 
     * @param value
     *     allowed object is
     *     {@link Boolean }
     *     
     */
    public void setIsStoreHead(Boolean value) {
        this.isStoreHead = value;
    }

}
