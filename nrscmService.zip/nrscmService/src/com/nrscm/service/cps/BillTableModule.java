package com.nrscm.service.cps;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.nrscm.service.Bill;
import com.nrscm.service.BillItems;
import com.nrscm.service.Item;
import com.nrscm.service.Messages;
import com.nrscm.service.ObjectFactory;

public class BillTableModule {
	// RAJU BEGINS	
	  public static Messages validateForGetBill(Bill bill,Messages valMessages){
		  List<String> validationMessages=valMessages.getMessages();
			if(bill.getBillId()==null){
				validationMessages.add("Need Bill Id");
				System.out.println("Need Bill Id");
			}
			return valMessages;
	  }
	  
	  
	  //public static Messages vaidateForCreateBill(Bill bill, Messages valMessages){

	  public static Messages validateForCreateBill(Bill bill,Messages valMessages){
		  List<String> validationMessages=valMessages.getMessages();
			 
			if(bill.getBillItems()==null){
				validationMessages.add("Need Bill Items to be added");
				System.out.println("Need Bill Itemsto be added");
			}
			
			if(bill.getBillItems()!=null&&!bill.getBillItems().getBillItems().isEmpty()){
				for(int i=0; i<bill.getBillItems().getBillItems().size(); i++)
				{
					Item item=bill.getBillItems().getBillItems().get(i);
					if(item.getId()==null){
						validationMessages.add("Need Item Id");
						System.out.println("Need Item Id");
					}
					if(item.getQuantity()==null){
						validationMessages.add("Need Bill Items to be added");
						System.out.println("Need Bill Itemsto be added");
					}
				}
			}
			
			if(bill.getBillAmount()==null){
				validationMessages.add("Need Bill Amount");
				System.out.println("Need Bill Amount");
			}
			
			/*if(bill.getBillDate()==null){
				validationMessages.add("Need Bill date");
				System.out.println("Need Bill date");
			}*/
			
			return valMessages;
	    }     
  
      public static Bill mapGetBillResultSetToBill(ResultSet rs){    
    	  ObjectFactory of=new ObjectFactory();
  		  Bill bill=of.createBill();
  		  try{ 
  			if(rs.next()){
  				bill.setBillId(rs.getInt("BILL_ID"));  
  				//bill.setBillItems(rs.getBillItems("BILL_ITEMS"));
                bill.setDiscountAvailed(rs.getBigDecimal("DISCOUNT_AVAILED"));
                bill.setBillAmount(rs.getBigDecimal("BILL_AMOUNT"));
                bill.setCustomerCard(of.createCustomerCard());
                bill.getCustomerCard().setCardNumber(rs.getInt("CARD_ID"));
  		        bill.setOldBillRef(of.createBill());	
  		        bill.getOldBillRef().setBillId(rs.getInt("OLD_BILL_REF")); 
  		        return bill;
  			  }     
	  		}catch(SQLException e){
					System.out.println("BillTableModule: SQL Exception");
					e.printStackTrace();
			}
  			return null;  
  		}
  
      public static BillItems mapGetBillItemsResultSetToBillItems(ResultSet rs){
    	  
    	  
    	  ObjectFactory of=new ObjectFactory(); 
    	  BillItems billItems=of.createBillItems();
    	  List<Item> items=billItems.getBillItems();
    	  try{
    		  while(rs.next()){
    			  Item item=of.createItem();
    			  item.setId(rs.getInt("ITEM_ID"));
    			  item.setQuantity(rs.getBigDecimal("QUANTITY"));
    			  items.add(item);
    		  }
    		  return billItems;
    	  }
    	  catch(SQLException e){
				System.out.println("BillTableModule: SQL Exception");
				e.printStackTrace();
		}
		return null; 
    }
      
    // RAJU ENDS
      
    // LAVANYA BEGINS
      /*public static Messages vaidateForCreateBill(Bill bill, Messages valMessages){
  		List<String> validationMessages=valMessages.getMessages();
  		if(item.getId()==null){
  			validationMessages.add("Need id for item");
  			System.out.println("Need id for item");
  		}
  		if(bill.getBillId()==null){
  			validationMessages.add("Need BILL ID");
  			System.out.println("Need BILL ID");
  		}
  		if(bill.getlistItems()=null){
  			validationMessages.add("Need ListItems");
  			System.out.println("Need ListItems");
  		}
  		if(bill.getBillAmount()==null){
  			validationMessages.add("Need Bill amount");
  			System.out.println("Need Bill Amount");
  		}
  		if(bill.getBillDate()!=null){
  			validationMessages.add("Need date");
  			System.out.println("Need date");
  		}
  		
  		return valMessages;
  	}*/  
      
      
    // LAVANYA ENDS  
      
} 
      
		
  		


