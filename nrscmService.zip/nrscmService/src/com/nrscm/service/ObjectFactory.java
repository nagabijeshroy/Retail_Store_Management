
package com.nrscm.service;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.nrscm.service package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.nrscm.service
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link RemoveDepartmentResponse }
     * 
     */
    public RemoveDepartmentResponse createRemoveDepartmentResponse() {
        return new RemoveDepartmentResponse();
    }

    /**
     * Create an instance of {@link Messages }
     * 
     */
    public Messages createMessages() {
        return new Messages();
    }

    /**
     * Create an instance of {@link AddDepartmentResponse }
     * 
     */
    public AddDepartmentResponse createAddDepartmentResponse() {
        return new AddDepartmentResponse();
    }

    /**
     * Create an instance of {@link EditDepartmentResponse }
     * 
     */
    public EditDepartmentResponse createEditDepartmentResponse() {
        return new EditDepartmentResponse();
    }

    /**
     * Create an instance of {@link Department }
     * 
     */
    public Department createDepartment() {
        return new Department();
    }

    /**
     * Create an instance of {@link DeleteEmployeeRequest }
     * 
     */
    public DeleteEmployeeRequest createDeleteEmployeeRequest() {
        return new DeleteEmployeeRequest();
    }

    /**
     * Create an instance of {@link Employee }
     * 
     */
    public Employee createEmployee() {
        return new Employee();
    }

    /**
     * Create an instance of {@link ViewStoreListResponse }
     * 
     */
    public ViewStoreListResponse createViewStoreListResponse() {
        return new ViewStoreListResponse();
    }

    /**
     * Create an instance of {@link StoreDetails }
     * 
     */
    public StoreDetails createStoreDetails() {
        return new StoreDetails();
    }

    /**
     * Create an instance of {@link SearchEmployeeResponse }
     * 
     */
    public SearchEmployeeResponse createSearchEmployeeResponse() {
        return new SearchEmployeeResponse();
    }

    /**
     * Create an instance of {@link ViewDepartmentListResponse }
     * 
     */
    public ViewDepartmentListResponse createViewDepartmentListResponse() {
        return new ViewDepartmentListResponse();
    }

    /**
     * Create an instance of {@link DepartmentDetails }
     * 
     */
    public DepartmentDetails createDepartmentDetails() {
        return new DepartmentDetails();
    }

    /**
     * Create an instance of {@link UpdateStoreResponse }
     * 
     */
    public UpdateStoreResponse createUpdateStoreResponse() {
        return new UpdateStoreResponse();
    }

    /**
     * Create an instance of {@link UpdateEmployeeResponse }
     * 
     */
    public UpdateEmployeeResponse createUpdateEmployeeResponse() {
        return new UpdateEmployeeResponse();
    }

    /**
     * Create an instance of {@link ViewEmployeeResponse }
     * 
     */
    public ViewEmployeeResponse createViewEmployeeResponse() {
        return new ViewEmployeeResponse();
    }

    /**
     * Create an instance of {@link EmployeeDetails }
     * 
     */
    public EmployeeDetails createEmployeeDetails() {
        return new EmployeeDetails();
    }

    /**
     * Create an instance of {@link AddDepartmentRequest }
     * 
     */
    public AddDepartmentRequest createAddDepartmentRequest() {
        return new AddDepartmentRequest();
    }

    /**
     * Create an instance of {@link ViewStoreListRequest }
     * 
     */
    public ViewStoreListRequest createViewStoreListRequest() {
        return new ViewStoreListRequest();
    }

    /**
     * Create an instance of {@link AddStoreRequest }
     * 
     */
    public AddStoreRequest createAddStoreRequest() {
        return new AddStoreRequest();
    }

    /**
     * Create an instance of {@link Store }
     * 
     */
    public Store createStore() {
        return new Store();
    }

    /**
     * Create an instance of {@link UpdateStoreRequest }
     * 
     */
    public UpdateStoreRequest createUpdateStoreRequest() {
        return new UpdateStoreRequest();
    }

    /**
     * Create an instance of {@link UpdateEmployeeRequest }
     * 
     */
    public UpdateEmployeeRequest createUpdateEmployeeRequest() {
        return new UpdateEmployeeRequest();
    }

    /**
     * Create an instance of {@link RemoveDepartmentRequest }
     * 
     */
    public RemoveDepartmentRequest createRemoveDepartmentRequest() {
        return new RemoveDepartmentRequest();
    }

    /**
     * Create an instance of {@link AddEmployeeResponse }
     * 
     */
    public AddEmployeeResponse createAddEmployeeResponse() {
        return new AddEmployeeResponse();
    }

    /**
     * Create an instance of {@link DeleteEmployeeResponse }
     * 
     */
    public DeleteEmployeeResponse createDeleteEmployeeResponse() {
        return new DeleteEmployeeResponse();
    }

    /**
     * Create an instance of {@link ViewDepartmentListRequest }
     * 
     */
    public ViewDepartmentListRequest createViewDepartmentListRequest() {
        return new ViewDepartmentListRequest();
    }

    /**
     * Create an instance of {@link AddEmployeeRequest }
     * 
     */
    public AddEmployeeRequest createAddEmployeeRequest() {
        return new AddEmployeeRequest();
    }

    /**
     * Create an instance of {@link EditDepartmentRequest }
     * 
     */
    public EditDepartmentRequest createEditDepartmentRequest() {
        return new EditDepartmentRequest();
    }

    /**
     * Create an instance of {@link SearchEmployeeRequest }
     * 
     */
    public SearchEmployeeRequest createSearchEmployeeRequest() {
        return new SearchEmployeeRequest();
    }

    /**
     * Create an instance of {@link ViewEmployeeRequest }
     * 
     */
    public ViewEmployeeRequest createViewEmployeeRequest() {
        return new ViewEmployeeRequest();
    }

    /**
     * Create an instance of {@link AddStoreResponse }
     * 
     */
    public AddStoreResponse createAddStoreResponse() {
        return new AddStoreResponse();
    }

    /**
     * Create an instance of {@link UpdateClearanceResponse }
     * 
     */
    public UpdateClearanceResponse createUpdateClearanceResponse() {
        return new UpdateClearanceResponse();
    }

    /**
     * Create an instance of {@link UpdateClearanceRequest }
     * 
     */
    public UpdateClearanceRequest createUpdateClearanceRequest() {
        return new UpdateClearanceRequest();
    }

    /**
     * Create an instance of {@link CreateBillResponse }
     * 
     */
    public CreateBillResponse createCreateBillResponse() {
        return new CreateBillResponse();
    }

    /**
     * Create an instance of {@link RemoveClearanceResponse }
     * 
     */
    public RemoveClearanceResponse createRemoveClearanceResponse() {
        return new RemoveClearanceResponse();
    }

    /**
     * Create an instance of {@link Promotion }
     * 
     */
    public Promotion createPromotion() {
        return new Promotion();
    }

    /**
     * Create an instance of {@link DeleteItemRequest }
     * 
     */
    public DeleteItemRequest createDeleteItemRequest() {
        return new DeleteItemRequest();
    }

    /**
     * Create an instance of {@link AddPromotionRequest }
     * 
     */
    public AddPromotionRequest createAddPromotionRequest() {
        return new AddPromotionRequest();
    }

    /**
     * Create an instance of {@link CreateCustomerCardRequest }
     * 
     */
    public CreateCustomerCardRequest createCreateCustomerCardRequest() {
        return new CreateCustomerCardRequest();
    }

    /**
     * Create an instance of {@link Clearance }
     * 
     */
    public Clearance createClearance() {
        return new Clearance();
    }

    /**
     * Create an instance of {@link GetClearanceForItemResponse }
     * 
     */
    public GetClearanceForItemResponse createGetClearanceForItemResponse() {
        return new GetClearanceForItemResponse();
    }

    /**
     * Create an instance of {@link GetItemRequest }
     * 
     */
    public GetItemRequest createGetItemRequest() {
        return new GetItemRequest();
    }

    /**
     * Create an instance of {@link CreateItemRequest }
     * 
     */
    public CreateItemRequest createCreateItemRequest() {
        return new CreateItemRequest();
    }

    /**
     * Create an instance of {@link RemovePromotionResponse }
     * 
     */
    public RemovePromotionResponse createRemovePromotionResponse() {
        return new RemovePromotionResponse();
    }

    /**
     * Create an instance of {@link SearchPromotionItemResponse }
     * 
     */
    public SearchPromotionItemResponse createSearchPromotionItemResponse() {
        return new SearchPromotionItemResponse();
    }

    /**
     * Create an instance of {@link Item }
     * 
     */
    public Item createItem() {
        return new Item();
    }

    /**
     * Create an instance of {@link UpdateCardDetailsRequest }
     * 
     */
    public UpdateCardDetailsRequest createUpdateCardDetailsRequest() {
        return new UpdateCardDetailsRequest();
    }

    /**
     * Create an instance of {@link SearchClearanceItemRequest }
     * 
     */
    public SearchClearanceItemRequest createSearchClearanceItemRequest() {
        return new SearchClearanceItemRequest();
    }

    /**
     * Create an instance of {@link AddPromotionResponse }
     * 
     */
    public AddPromotionResponse createAddPromotionResponse() {
        return new AddPromotionResponse();
    }

    /**
     * Create an instance of {@link UpdateCustomerCardRequest }
     * 
     */
    public UpdateCustomerCardRequest createUpdateCustomerCardRequest() {
        return new UpdateCustomerCardRequest();
    }

    /**
     * Create an instance of {@link RemoveClearanceRequest }
     * 
     */
    public RemoveClearanceRequest createRemoveClearanceRequest() {
        return new RemoveClearanceRequest();
    }

    /**
     * Create an instance of {@link CreateBillRequest }
     * 
     */
    public CreateBillRequest createCreateBillRequest() {
        return new CreateBillRequest();
    }

    /**
     * Create an instance of {@link GetItemsResponse }
     * 
     */
    public GetItemsResponse createGetItemsResponse() {
        return new GetItemsResponse();
    }

    /**
     * Create an instance of {@link UpdateItemResponse }
     * 
     */
    public UpdateItemResponse createUpdateItemResponse() {
        return new UpdateItemResponse();
    }

    /**
     * Create an instance of {@link AddClearanceRequest }
     * 
     */
    public AddClearanceRequest createAddClearanceRequest() {
        return new AddClearanceRequest();
    }

    /**
     * Create an instance of {@link CustomerCard }
     * 
     */
    public CustomerCard createCustomerCard() {
        return new CustomerCard();
    }

    /**
     * Create an instance of {@link RemovePromotionRequest }
     * 
     */
    public RemovePromotionRequest createRemovePromotionRequest() {
        return new RemovePromotionRequest();
    }

    /**
     * Create an instance of {@link CreateNewBillResponse }
     * 
     */
    public CreateNewBillResponse createCreateNewBillResponse() {
        return new CreateNewBillResponse();
    }

    /**
     * Create an instance of {@link DeleteItemResponse }
     * 
     */
    public DeleteItemResponse createDeleteItemResponse() {
        return new DeleteItemResponse();
    }

    /**
     * Create an instance of {@link GetItemResponse }
     * 
     */
    public GetItemResponse createGetItemResponse() {
        return new GetItemResponse();
    }

    /**
     * Create an instance of {@link SearchPromotionItemRequest }
     * 
     */
    public SearchPromotionItemRequest createSearchPromotionItemRequest() {
        return new SearchPromotionItemRequest();
    }

    /**
     * Create an instance of {@link UpdatePromotionRequest }
     * 
     */
    public UpdatePromotionRequest createUpdatePromotionRequest() {
        return new UpdatePromotionRequest();
    }

    /**
     * Create an instance of {@link GetCardDetailsResponse }
     * 
     */
    public GetCardDetailsResponse createGetCardDetailsResponse() {
        return new GetCardDetailsResponse();
    }

    /**
     * Create an instance of {@link GetCardDetailsRequest }
     * 
     */
    public GetCardDetailsRequest createGetCardDetailsRequest() {
        return new GetCardDetailsRequest();
    }

    /**
     * Create an instance of {@link GetClearanceForItemRequest }
     * 
     */
    public GetClearanceForItemRequest createGetClearanceForItemRequest() {
        return new GetClearanceForItemRequest();
    }

    /**
     * Create an instance of {@link UpdateCardDetailsResponse }
     * 
     */
    public UpdateCardDetailsResponse createUpdateCardDetailsResponse() {
        return new UpdateCardDetailsResponse();
    }

    /**
     * Create an instance of {@link BillItems }
     * 
     */
    public BillItems createBillItems() {
        return new BillItems();
    }

    /**
     * Create an instance of {@link UpdatePromotionResponse }
     * 
     */
    public UpdatePromotionResponse createUpdatePromotionResponse() {
        return new UpdatePromotionResponse();
    }

    /**
     * Create an instance of {@link UpdateCustomerCardResponse }
     * 
     */
    public UpdateCustomerCardResponse createUpdateCustomerCardResponse() {
        return new UpdateCustomerCardResponse();
    }

    /**
     * Create an instance of {@link AddClearanceResponse }
     * 
     */
    public AddClearanceResponse createAddClearanceResponse() {
        return new AddClearanceResponse();
    }

    /**
     * Create an instance of {@link SearchBillItemResponse }
     * 
     */
    public SearchBillItemResponse createSearchBillItemResponse() {
        return new SearchBillItemResponse();
    }

    /**
     * Create an instance of {@link GetExistingBillRequest }
     * 
     */
    public GetExistingBillRequest createGetExistingBillRequest() {
        return new GetExistingBillRequest();
    }

    /**
     * Create an instance of {@link CreateCustomerCardResponse }
     * 
     */
    public CreateCustomerCardResponse createCreateCustomerCardResponse() {
        return new CreateCustomerCardResponse();
    }

    /**
     * Create an instance of {@link CreateItemResponse }
     * 
     */
    public CreateItemResponse createCreateItemResponse() {
        return new CreateItemResponse();
    }

    /**
     * Create an instance of {@link Items }
     * 
     */
    public Items createItems() {
        return new Items();
    }

    /**
     * Create an instance of {@link CreateNewBillRequest }
     * 
     */
    public CreateNewBillRequest createCreateNewBillRequest() {
        return new CreateNewBillRequest();
    }

    /**
     * Create an instance of {@link SearchClearanceItemResponse }
     * 
     */
    public SearchClearanceItemResponse createSearchClearanceItemResponse() {
        return new SearchClearanceItemResponse();
    }

    /**
     * Create an instance of {@link UpdateItemRequest }
     * 
     */
    public UpdateItemRequest createUpdateItemRequest() {
        return new UpdateItemRequest();
    }

    /**
     * Create an instance of {@link GetPromotionForItemRequest }
     * 
     */
    public GetPromotionForItemRequest createGetPromotionForItemRequest() {
        return new GetPromotionForItemRequest();
    }

    /**
     * Create an instance of {@link GetExistingBillResponse }
     * 
     */
    public GetExistingBillResponse createGetExistingBillResponse() {
        return new GetExistingBillResponse();
    }

    /**
     * Create an instance of {@link Bill }
     * 
     */
    public Bill createBill() {
        return new Bill();
    }

    /**
     * Create an instance of {@link SearchBillItemRequest }
     * 
     */
    public SearchBillItemRequest createSearchBillItemRequest() {
        return new SearchBillItemRequest();
    }

    /**
     * Create an instance of {@link GetItemsRequest }
     * 
     */
    public GetItemsRequest createGetItemsRequest() {
        return new GetItemsRequest();
    }

    /**
     * Create an instance of {@link GetPromotionForItemResponse }
     * 
     */
    public GetPromotionForItemResponse createGetPromotionForItemResponse() {
        return new GetPromotionForItemResponse();
    }

}
