package com.nrscm.service.DataGateway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nrscm.service.Department;
import com.nrscm.service.DepartmentDetails;
import com.nrscm.service.Utility.JDBCHelper;

public class DepartmentDataGateway {
	Connection connection = JDBCHelper.connect();
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public String removeDepartment(Department department) {
		String result = "false";
		try {
			String query = "delete from department where departmentid = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setInt(1, department.getId());
			System.out.println(query + "pstmt: ");
			if (pstmt.execute() != false) {
				result = "true";
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	public Boolean editDepartment(Department department) {
		Boolean result = false;
		try {
			String query = "update department set department_name = ? , store_id = ? , department_head = ? , employee_id = ? where departmentid = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, department.getName());
			pstmt.setInt(2, department.getStoreId());
			pstmt.setString(3, department.getDepartmentHead());
			pstmt.setInt(4, department.getEid());
			pstmt.setInt(5, department.getId());
			System.out.println(query + "pstmt: ");
			if (pstmt.executeUpdate() != 0) {
				result = true;
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	public Boolean addDepartment(Department department) {
		Boolean result = false;
		try {
			String query = "insert into department (department_name , store_id , employee_id , department_head) values (? , ? , ? , ?)";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, department.getName());
			pstmt.setInt(2, department.getStoreId());
			pstmt.setInt(3, department.getEid());
			pstmt.setString(4,department.getDepartmentHead());
			System.out.println(query + "pstmt: ");
			if (pstmt.execute() != false) {
				result = true;
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	public DepartmentDetails viewDepartmentList(Department department) {
		DepartmentDetails departmentDetails = new DepartmentDetails();
		Department department2 ;
		try {
			String query = "select * from department where store_id = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setInt(1, department.getStoreId());
			System.out.println(query + "pstmt: ");
			rs = pstmt.executeQuery();
			while(rs.next()){
				department2 = new Department();
				department2.setDepartmentHead(rs.getString("department_head"));
				department2.setEid(rs.getInt("employee_id"));
				department2.setName(rs.getString("department_name"));
				department2.setId(rs.getInt("departmentid"));
				department2.setStoreId(rs.getInt("store_id"));
				departmentDetails.getDepartmentDetails().add(department2);
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		for (Department department3:departmentDetails.getDepartmentDetails()) {
			System.out.println("department_Name"+department3.getName());
		}
		return departmentDetails;

	}

}
