package com.nrscm.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.jws.WebService;

import com.nrscm.service.item.ItemDataGateway;
import com.nrscm.service.item.ItemTableModule;
import com.nrscm.service.pc.ClearanceDataGateway;
import com.nrscm.service.pc.ClearanceTableModule;
import com.nrscm.service.pc.PromotionDataGateway;
import com.nrscm.service.pc.PromotionsTableModule;

@WebService(name = "PCServiceInterface", serviceName = "PCServiceClient", endpointInterface = "com.nrscm.service.PCServiceInterface", targetNamespace = "http://service.nrscm.com/", portName = "PCServicePort", wsdlLocation = "/wsdl/pc.wsdl")
public class PCService implements PCServiceInterface {

	// have methods to get all promotions and clearances instead of seacrh promos and clearances? 
	
	@Override
	public AddClearanceResponse addClearance(AddClearanceRequest addClearanceRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* createClearance");
		Clearance clearance=addClearanceRequestMessage.getClearance();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		//List<String> messageStrings=validationMessages.getMessages();
		validationMessages=ClearanceTableModule.validateForCreateClearance(clearance, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			ClearanceDataGateway clearanceDataGateway=new ClearanceDataGateway();
			ResultSet rs=clearanceDataGateway.createClearance(clearance);
			try {
				if(rs.next()){
					clearance.setId(rs.getInt(1));
					if(!clearance.getItems().isEmpty()){
						for(int i=0;i<clearance.getItems().size();i++){
							ResultSet checkRs=clearanceDataGateway.checkIfItemIsUnderClearance(clearance.getItems().get(i));
							if(checkRs.next()){
								validationMessages.getMessages().add("Item with id "+clearance.getItems().get(i).getId()+" is already present in clearance with id "+ checkRs.getInt("CLEARANCE_ID")+". So, it will not be added to this clearance");								
								clearance.getItems().remove(i);
							}
						}
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			clearanceDataGateway.insertClearanceItems(clearance);
		}
		AddClearanceResponse addClearanceResponseType=of.createAddClearanceResponse();
		addClearanceResponseType.setClearance(clearance);
		//createClearanceResponseType.setStoreId(parameters.getStoreId());
		addClearanceResponseType.setValidationMessages(validationMessages);
		return addClearanceResponseType;
	}
	
	
	@Override
	public UpdateClearanceResponse updateClearance(UpdateClearanceRequest updateClearanceRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* updateClearance");
		Clearance clearance=updateClearanceRequestMessage.getClearance();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=ClearanceTableModule.validateForUpdateClearance(clearance, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			ClearanceDataGateway clearanceDataGateway=new ClearanceDataGateway();
			boolean inserted=clearanceDataGateway.updateClearance(clearance);
		}
		UpdateClearanceResponse updateClearanceResponse=of.createUpdateClearanceResponse();
		updateClearanceResponse.setClearance(clearance);
		updateClearanceResponse.setValidationMessages(validationMessages);
		return updateClearanceResponse;
	}
	
	@Override
	public RemoveClearanceResponse removeClearance(RemoveClearanceRequest removeClearanceRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* removeClearance");
		Clearance clearance=removeClearanceRequestMessage.getClearance();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=ClearanceTableModule.vaidateForRemoveClearance(clearance, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			ClearanceDataGateway clearanceDataGateway=new ClearanceDataGateway();
			boolean inserted=clearanceDataGateway.removeClearance(clearance);
		}
		RemoveClearanceResponse removeClearanceResponse=of.createRemoveClearanceResponse();
		removeClearanceResponse.setClearance(clearance);
		removeClearanceResponse.setValidationMessages(validationMessages);
		return removeClearanceResponse;
	}
	
	@Override
	public AddPromotionResponse addPromotion(AddPromotionRequest addPromotionRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* createPromotion");
		Promotion promotion=addPromotionRequestMessage.getPromotion();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		//List<String> messageStrings=validationMessages.getMessages();
		validationMessages=PromotionsTableModule.validateForCreatePromotion(promotion, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			PromotionDataGateway PromotionDataGateway=new PromotionDataGateway();
			boolean inserted=PromotionDataGateway.createPromotion(promotion);
		}
		AddPromotionResponse addPromotionResponseType=of.createAddPromotionResponse();
		addPromotionResponseType.setPromotion(promotion);
		//createPromotionResponseType.setStoreId(parameters.getStoreId());
		addPromotionResponseType.setValidationMessages(validationMessages);
		return addPromotionResponseType;
	}	

	@Override
	public UpdatePromotionResponse updatePromotion(UpdatePromotionRequest updatePromotionRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* updatePromotion");
		Promotion promotion=updatePromotionRequestMessage.getPromotion();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=PromotionsTableModule.validateForUpdatePromotion(promotion, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			PromotionDataGateway promotionDataGateway=new PromotionDataGateway();
			boolean inserted=promotionDataGateway.updatePromotion(promotion);
		}
		UpdatePromotionResponse updatePromotionResponse=of.createUpdatePromotionResponse();
		updatePromotionResponse.setPromotion(promotion);
		updatePromotionResponse.setValidationMessages(validationMessages);
		return updatePromotionResponse;
	}


	
	
	@Override
	public RemovePromotionResponse removePromotion(RemovePromotionRequest removePromotionRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* removePromotion");
		Promotion promotion=removePromotionRequestMessage.getPromotion();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=PromotionsTableModule.vaidateForRemovePromotion(promotion, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			PromotionDataGateway promotionDataGateway=new PromotionDataGateway();
			boolean inserted=promotionDataGateway.removePromotion(promotion);
		}
		RemovePromotionResponse removePromotionResponse=of.createRemovePromotionResponse();
		removePromotionResponse.setPromotion(promotion);
		removePromotionResponse.setValidationMessages(validationMessages);
		return removePromotionResponse;
	}
	
	@Override
	public SearchPromotionItemResponse searchPromotionItem(SearchPromotionItemRequest searchPromotionItemRequestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	/*@Override
	public SearchClearanceItemResponse searchClearanceItem(SearchClearanceItemRequest searchClearanceItemRequestMessage) {
		// TODO Auto-generated method stub
		return null;
	}*/

	

	@Override
	public GetClearanceForItemResponse getClearanceForItem(GetClearanceForItemRequest getClearanceForItemRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* getClearanceForItem");
		Item item=getClearanceForItemRequestMessage.getItem();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=ClearanceTableModule.vaidateForGetClearanceForItem(item, validationMessages);
		Clearance clearance=null;
		if(validationMessages.getMessages().isEmpty()){
			ClearanceDataGateway clearanceDataGateway=new ClearanceDataGateway();
			ResultSet rs=clearanceDataGateway.getClearanceForItem(item);
			clearance=ClearanceTableModule.mapGetClearanceForItemResultSetToClearance(rs);
		}
		GetClearanceForItemResponse getClearanceForItemResponse=of.createGetClearanceForItemResponse();
		getClearanceForItemResponse.setClearance(clearance);
		getClearanceForItemResponse.setItem(item);
		getClearanceForItemResponse.setValidationMessages(validationMessages);
		return getClearanceForItemResponse;
	}

	@Override
	public GetPromotionForItemResponse getPromotionForItem(GetPromotionForItemRequest getPromotionForItemRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* getPromotionForItem");
		Item item=getPromotionForItemRequestMessage.getItem();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=PromotionsTableModule.vaidateForGetPromotionForItem(item, validationMessages);
		Promotion promotion=null;
		if(validationMessages.getMessages().isEmpty()){
			PromotionDataGateway promotionDataGateway=new PromotionDataGateway();
			ResultSet rs=promotionDataGateway.getPromotionForItem(item);
			promotion=PromotionsTableModule.mapGetPromotionForItemResultSetToPromotion(rs);
		}
		GetPromotionForItemResponse getPromotionForItemResponse=of.createGetPromotionForItemResponse();
		getPromotionForItemResponse.setPromotion(promotion);
		getPromotionForItemResponse.setItem(item);
		getPromotionForItemResponse.setValidationMessages(validationMessages);
		return getPromotionForItemResponse;
	}


}
