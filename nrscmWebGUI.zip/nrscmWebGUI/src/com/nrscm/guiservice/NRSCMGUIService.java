package com.nrscm.guiservice;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;

import com.nrscm.guiservice.facade.GUIFacade;
import com.nrscm.service.AddDepartmentResponse;
import com.nrscm.service.AddEmployeeResponse;
import com.nrscm.service.AddStoreResponse;
import com.nrscm.service.DeleteEmployeeResponse;
import com.nrscm.service.Department;
import com.nrscm.service.DepartmentDetails;
import com.nrscm.service.EditDepartmentResponse;
import com.nrscm.service.Employee;
import com.nrscm.service.EmployeeDetails;
import com.nrscm.service.Messages;
import com.nrscm.service.RemoveDepartmentResponse;
import com.nrscm.service.SearchEmployeeResponse;
import com.nrscm.service.Store;
import com.nrscm.service.StoreDetails;
import com.nrscm.service.UpdateEmployeeResponse;
import com.nrscm.service.UpdateStoreResponse;
import com.nrscm.service.ViewEmployeeResponse;

@Path("/nrscm")
public class NRSCMGUIService {
	HttpSession session = null;
	GUIFacade gUIFacade=new GUIFacade();
	@POST
	@Path("/addItem")
	public Response addItem(@FormParam("jsonStringTextArea") String jsonItem){
		String addItemResponse=gUIFacade.addItem(jsonItem);
		return Response.status(200).entity(addItemResponse).build();
	}
	
	@GET
	@Path("/searchItem")
	public Response searchItem(@QueryParam("jsonStringTextArea") String jsonItem){
		String searchItemsResponse=gUIFacade.searchItem(jsonItem);
		return Response.status(200).entity(searchItemsResponse).build();
	}
	
	@POST
	@Path("/updateItem")
	public Response updateItem(@FormParam("jsonStringTextArea") String jsonItem){
		String updateItemResponse=gUIFacade.updateItem(jsonItem);
		return Response.status(200).entity(updateItemResponse).build();
	}
	
	@GET
	@Path("/deleteItem")
	public Response deleteItem(@QueryParam("jsonStringTextArea") String jsonItem){
		String deleteItemResponse=gUIFacade.deleteItem(jsonItem);
		return Response.status(200).entity(deleteItemResponse).build();
	}
	
	@GET
	@Path("/getCardDetails")
	public Response getCardDetails(@QueryParam("jsonStringTextArea") String jsonCard){
		String getCardDetailsRespaonse=gUIFacade.getCardDetails(jsonCard);
		return Response.status(200).entity(getCardDetailsRespaonse).build();
	}
	
	@GET
	@Path("/getExistingBill")
	public Response getExistingBill(@QueryParam("jsonStringTextArea") String jsonBill){
		String getExistingBillResponse=gUIFacade.getExistingBill(jsonBill);
		return Response.status(200).entity(getExistingBillResponse).build();
	}
	
	@POST
	@Path("/generateNewBill")
	public Response generateNewBill(@FormParam("jsonStringTextArea") String jsonBill){
		String generateNewBillResponse=gUIFacade.generateNewBill(jsonBill);
		return Response.status(200).entity(generateNewBillResponse).build();
	}
	
	@POST
	@Path("/createCustomerCard")
	public Response createCustomerCard(@FormParam("jsonStringTextArea") String jsonCard){
		String createCustomerCardResponse=gUIFacade.createCustomerCard(jsonCard);
		return Response.status(200).entity(createCustomerCardResponse).build();
	}
	
	@GET
	@Path("/getItemPromotion")
	public Response getItemPromotion(@QueryParam("jsonStringTextArea") String jsonItem){
		String getItemPromotionResponse=gUIFacade.getItemPromotion(jsonItem);
		return Response.status(200).entity(getItemPromotionResponse).build();
	}
	
	@GET
	@Path("/getItemClearance")
	public Response getItemClearance(@QueryParam("jsonStringTextArea") String jsonItem){
		String getItemClearanceResponse=gUIFacade.getItemClearance(jsonItem);
		return Response.status(200).entity(getItemClearanceResponse).build();
	}
	
	@POST
	@Path("/addPromotion")
	public Response addPromotion(@FormParam("jsonStringTextArea") String jsonPromotion){
		String addPromotionResponse=gUIFacade.addPromotion(jsonPromotion);
		return Response.status(200).entity(addPromotionResponse).build();
	}
	
	@POST
	@Path("/updatePromotion")
	public Response updatePromotion(@FormParam("jsonStringTextArea") String jsonPromotion){
		String updatePromotionResponse=gUIFacade.updatePromotion(jsonPromotion);
		return Response.status(200).entity(updatePromotionResponse).build();
	}
	
	@GET
	@Path("/removePromotion")
	public Response removePromotion(@QueryParam("jsonStringTextArea") String jsonPromotion){
		String removePromotionResponse=gUIFacade.removePromotion(jsonPromotion);
		return Response.status(200).entity(removePromotionResponse).build();
	}
	
	@POST
	@Path("/createClearance")
	public Response createClearance(@FormParam("jsonStringTextArea") String jsonClearance){
		String createClearanceResponse=gUIFacade.createClearance(jsonClearance);
		return Response.status(200).entity(createClearanceResponse).build();
	}
	
	@POST
	@Path("/addStore")
	@Produces("text/html")
	public Response addStoreDetails(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String storeName = request.getParameter("storeName");
		String storeLocation = request.getParameter("storeLocation");
		String storeDBName = request.getParameter("storeDataBase");
		Store store = new Store();
		store.setStoreName(storeName);
		store.setLocation(storeLocation);
		store.setStoreDB(storeDBName);
		AddStoreResponse addStoreResponse = gUIFacade.addStoreDetails(store);
		session.setAttribute("StoreList", addStoreResponse);
		if (addStoreResponse != null) {
			StoreDetails storeDetails = gUIFacade.viewStoreList();
			ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
			session.setAttribute("storeDetails", storeDetails);
			session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
			String contextPath = request.getContextPath();
			response.sendRedirect(contextPath + "/CNS.jsp");
		}
		return null;
	}

	@POST
	@Path("/updateStore")
	@Produces("text/html")
	public Response updateStore(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String storeName = request.getParameter("storeName");
		String storeLocation = request.getParameter("storeLocation");
		String storeDBName = request.getParameter("storeDataBase");
		String storeHead = request.getParameter("storeHead");
		int storeId = (int) session.getAttribute("updateStoreId");
		Store store = new Store();
		store.setLocation(storeLocation);
		store.setStoreDB(storeDBName);
		store.setStoreId(storeId);
		store.setStoreName(storeName);
		store.setStoreHead(storeHead);
		UpdateStoreResponse updateStoreResponse = gUIFacade.updateStore(store);
		Messages messages = updateStoreResponse.getValidationMessages();
		for (String message : messages.getMessages()) {
			StoreDetails storeDetails = gUIFacade.viewStoreList();
			ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
			session.setAttribute("storeDetails", storeDetails);
			session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
			String contextPath = request.getContextPath();
			session.setAttribute("ErrorMessage", message);
			response.sendRedirect(contextPath + "/configureStoreDetails.jsp");
		}
		return null;
	}

	@POST
	@Path("/viewDepartmentList")
	public Response viewDepartmentList(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		int storeId = (int) session.getAttribute("updateStoreId");
		System.out.println(storeId);
		Store store = new Store();
		store.setStoreId(storeId);
		String name1 = "name";
		DepartmentDetails departmentDetails = gUIFacade.viewDepartmentList(store);
		session.setAttribute("departmentDetails", departmentDetails);
		StoreDetails storeDetails = gUIFacade.viewStoreList();
		ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
		session.setAttribute("storeDetails", storeDetails);
		session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
		return Response.status(200).entity(name1).build();
	}

	@POST
	@Path("/addDepartment")
	public Response addDepartment(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String departmentName = request.getParameter("departmenName");
		int departmentHead = Integer.parseInt(request.getParameter("departmentHead"));
		Department department = new Department();
		int storeId = (int) session.getAttribute("updateStoreId");
		department.setStoreId(storeId);
		department.setName(departmentName);
		ViewEmployeeResponse viewEmployeeResponse = gUIFacade.viewEmployee();
		EmployeeDetails employeeDetails = viewEmployeeResponse.getEmployeeDetails();
		for (Employee employee : employeeDetails.getEmployeeDetails()) {
			if(employee.getEid() == departmentHead){
				department.setDepartmentHead(employee.getName());
			}
		}
		Store store = new Store();
		store.setStoreId(storeId);
		department.setEid(departmentHead);
		AddDepartmentResponse addDepartmentResponse = gUIFacade.addDepartment(department);
		for (String messages : addDepartmentResponse.getValidationMessages().getMessages()) {
			DepartmentDetails departmentDetails = gUIFacade.viewDepartmentList(store);
			session.setAttribute("departmentDetails", departmentDetails);
			StoreDetails storeDetails = gUIFacade.viewStoreList();
			ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
			session.setAttribute("storeDetails", storeDetails);
			session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
			String contextPath = request.getContextPath();
			session.setAttribute("ErrorMessage", messages);
			response.sendRedirect(contextPath + "/configurDepartment.jsp");
		}
		return null;
	}

	@POST
	@Path("/updateDepartment")
	public Response updateDepartment(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String departmentName = request.getParameter("departmenName");
		int departmentHead = Integer.parseInt(request.getParameter("departmentHead"));
		int departmentId = Integer.parseInt(request.getParameter("departmentId"));
		Department department = new Department();
		int storeId = (int) session.getAttribute("updateStoreId");
		department.setStoreId(storeId);
		department.setName(departmentName);
		department.setEid(departmentHead);
		department.setId(departmentId);
		ViewEmployeeResponse viewEmployeeResponse = gUIFacade.viewEmployee();
		EmployeeDetails employeeDetails = viewEmployeeResponse.getEmployeeDetails();
		for (Employee employee : employeeDetails.getEmployeeDetails()) {
			if(employee.getEid() == departmentHead){
				department.setDepartmentHead(employee.getName());
			}
		}
		Store store = new Store();
		store.setStoreId(storeId);
		EditDepartmentResponse editDepartmentResponse = gUIFacade.editDepartment(department);
		for (String messages : editDepartmentResponse.getValidationMessages().getMessages()) {
			DepartmentDetails departmentDetails = gUIFacade.viewDepartmentList(store);
			session.setAttribute("departmentDetails", departmentDetails);
			StoreDetails storeDetails = gUIFacade.viewStoreList();
			ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
			session.setAttribute("storeDetails", storeDetails);
			session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
			String contextPath = request.getContextPath();
			session.setAttribute("ErrorMessage", messages);
			response.sendRedirect(contextPath + "/configurDepartment.jsp");
		}
		return null;
	}

	@POST
	@Path("/removeDepartment")
	public Response removeDepartment(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String departmentName = request.getParameter("departmenName");
		int departmentHead = Integer.parseInt(request.getParameter("departmentHead"));
		int departmentId = Integer.parseInt(request.getParameter("departmentId"));
		Department department = new Department();
		int storeId = (int) session.getAttribute("updateStoreId");
		department.setStoreId(storeId);
		department.setName(departmentName);
		department.setEid(departmentHead);
		department.setId(departmentId);
		ViewEmployeeResponse viewEmployeeResponse = gUIFacade.viewEmployee();
		EmployeeDetails employeeDetails = viewEmployeeResponse.getEmployeeDetails();
		for (Employee employee : employeeDetails.getEmployeeDetails()) {
			if(employee.getEid() == departmentHead){
				department.setDepartmentHead(employee.getName());
			}
		}
		Store store = new Store();
		store.setStoreId(storeId);
		RemoveDepartmentResponse removeDepartmentResponse = gUIFacade.removeDepartment(department);
		for (String messages : removeDepartmentResponse.getValidationMessages().getMessages()) {
			DepartmentDetails departmentDetails = gUIFacade.viewDepartmentList(store);
			session.setAttribute("departmentDetails", departmentDetails);
			StoreDetails storeDetails = gUIFacade.viewStoreList();
			ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
			session.setAttribute("storeDetails", storeDetails);
			session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
			String contextPath = request.getContextPath();
			session.setAttribute("ErrorMessage", messages);
			response.sendRedirect(contextPath + "/configurDepartment.jsp");
		}
		return null;
	}

	@POST
	@Path("/addEmployee")
	@Produces("text/html")
	public Response addEmployee(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String firstName = request.getParameter("firstName");
		String middleName = request.getParameter("middleName");
		String lastName = request.getParameter("lastName");
		String address1 = request.getParameter("address1");
		String designation = request.getParameter("designation");
		Employee employee = new Employee();
		employee.setName(firstName + " " + middleName + " " + lastName);
		employee.setEmployeeAddress(address1);
		employee.setEmployeeDesgnation(designation);
		employee.setStoreId(Integer.parseInt(request.getParameter("storeId")));
		AddEmployeeResponse addEmployeeResponse = gUIFacade.addEmployee(employee);
		for (String messages : addEmployeeResponse.getValidationMessages().getMessages()) {
			StoreDetails storeDetails = gUIFacade.viewStoreList();
			ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
			session.setAttribute("storeDetails", storeDetails);
			session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
			String contextPath = request.getContextPath();
			session.setAttribute("ErrorMessage", messages);
			response.sendRedirect(contextPath + "/addEmployee.jsp");
		}
		return null;
	}

	@POST
	@Path("/searchEmployee")
	@Produces("text/html")
	public Response searchEmployee(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		int employeeId = Integer.parseInt(request.getParameter("employeeId"));
		Employee employee = new Employee();
		employee.setEid(employeeId);
		SearchEmployeeResponse searchEmployeeResponse = gUIFacade.searchEmployee(employee);
		for (String message : searchEmployeeResponse.getValidationMessages().getMessages()) {
			session.setAttribute("Employee", searchEmployeeResponse.getEmployee());
			System.out.println(searchEmployeeResponse.getEmployee().getName());
			String contextPath = request.getContextPath();
			session.setAttribute("ErrorMessage", message);
			response.sendRedirect(contextPath + "/searchEmployee.jsp");
		}
		return null;
	}

	@POST
	@Path("/modifyEmployee")
	@Produces("text/html")
	public Response updateEmployee(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String name = request.getParameter("name");
		String address1 = request.getParameter("address1");
		String designation = request.getParameter("designation");
		String employeeId = request.getParameter("employeeId");
		Employee employee = new Employee();
		employee.setName(name);
		employee.setEmployeeAddress(address1);
		employee.setEmployeeDesgnation(designation);
		employee.setEid(Integer.parseInt(employeeId));
		int storeId = Integer.parseInt(request.getParameter("storeId"));
		employee.setStoreId(storeId);
		if (request.getParameter("clickedButton").equalsIgnoreCase("Update")) {
			UpdateEmployeeResponse updateEmployeeResponse = gUIFacade.updateEmployee(employee);
			for (String messages : updateEmployeeResponse.getValidationMessages().getMessages()) {

				StoreDetails storeDetails = gUIFacade.viewStoreList();
				ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
				session.setAttribute("storeDetails", storeDetails);
				session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
				session.setAttribute("Employee", employee);
				String contextPath = request.getContextPath();
				session.setAttribute("ErrorMessage", messages);
				response.sendRedirect(contextPath + "/searchEmployee.jsp");
			}
		} else if (request.getParameter("clickedButton").equalsIgnoreCase("Delete")) {

			DeleteEmployeeResponse deleteEmployeeResponse = gUIFacade.deleteEmployee(employee);
			for (String message : deleteEmployeeResponse.getValidationMessages().getMessages()) {

				StoreDetails storeDetails = gUIFacade.viewStoreList();
				ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
				session.setAttribute("storeDetails", storeDetails);
				session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
				String contextPath = request.getContextPath();
				session.setAttribute("ErrorMessage", message);
				response.sendRedirect(contextPath + "/searchEmployee.jsp");
			}
		}
		return null;
	}

	/*
	 * @POST
	 * 
	 * @Path("/deleteEmployee")
	 * 
	 * @Produces("text/html") public Response deleteEmployee(@Context
	 * HttpServletRequest request, @Context HttpServletResponse response) throws
	 * IOException, ServletException { session = request.getSession(); int
	 * employeeId = Integer.parseInt(request.getParameter("employeeId"));
	 * Employee employee = new Employee(); employee.setEid(employeeId); int
	 * storeId = Integer.parseInt(request.getParameter("storeId"));
	 * employee.setStoreId(storeId);
	 * 
	 * return null; }
	 */

	@POST
	@Path("/displayData")
	public Response displayData(@QueryParam("Name") String Name) {
		String name = "name";
		return Response.status(200).entity(name).build();
	}

	@POST
	@Path("/authenticateLogin")
	@Produces("text/html")
	public Response authenticateLogin(@Context HttpServletRequest request, @Context HttpServletResponse response) throws IOException, ServletException {
		session = request.getSession();
		String authenticateLogin = gUIFacade.authenticateLogin(request.getParameter("userName"));
		String loginId = request.getParameter("userName");
		if (authenticateLogin.equalsIgnoreCase("Bijesh")) {
			StoreDetails storeDetails = gUIFacade.viewStoreList();
			ViewEmployeeResponse employeeResponse = gUIFacade.viewEmployee();
			EmployeeDetails employee = employeeResponse.getEmployeeDetails();
			session.setAttribute("storeDetails", storeDetails);
			session.setAttribute("employeeDetails", employeeResponse.getEmployeeDetails());
			session.setAttribute("username", loginId);
			if(loginId.equalsIgnoreCase("Administrator")){
				String contextPath = request.getContextPath();
				response.sendRedirect(contextPath + "/index.jsp");
			}else{
				String contextPath = request.getContextPath();
				response.sendRedirect(contextPath + "/home.jsp");
			}
		}
		return null;
	}
	
}
