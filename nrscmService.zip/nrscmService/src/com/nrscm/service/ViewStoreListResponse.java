
package com.nrscm.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="storeDetails" type="{http://service.nrscm.com/}StoreDetails"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "storeDetails"
})
@XmlRootElement(name = "viewStoreListResponse")
public class ViewStoreListResponse {

    @XmlElement(required = true)
    protected StoreDetails storeDetails;

    /**
     * Gets the value of the storeDetails property.
     * 
     * @return
     *     possible object is
     *     {@link StoreDetails }
     *     
     */
    public StoreDetails getStoreDetails() {
        return storeDetails;
    }

    /**
     * Sets the value of the storeDetails property.
     * 
     * @param value
     *     allowed object is
     *     {@link StoreDetails }
     *     
     */
    public void setStoreDetails(StoreDetails value) {
        this.storeDetails = value;
    }

}
