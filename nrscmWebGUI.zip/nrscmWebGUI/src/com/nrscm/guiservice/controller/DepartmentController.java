package com.nrscm.guiservice.controller;

import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.AddDepartmentRequest;
import com.nrscm.service.AddDepartmentResponse;
import com.nrscm.service.CNSServiceInterface;
import com.nrscm.service.Department;
import com.nrscm.service.DepartmentDetails;
import com.nrscm.service.EditDepartmentRequest;
import com.nrscm.service.EditDepartmentResponse;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.RemoveDepartmentRequest;
import com.nrscm.service.RemoveDepartmentResponse;
import com.nrscm.service.Store;
import com.nrscm.service.ViewDepartmentListRequest;
import com.nrscm.service.ViewDepartmentListResponse;

public class DepartmentController {
	CNSServiceInterface cnsServiceInterface = NRSCMClient.getCNSServiceInterface();
	ObjectFactory objectFactory = new ObjectFactory();
	public DepartmentDetails viewDepartmentList(Store store) {
		ViewDepartmentListRequest viewDepartmentListRequest = objectFactory.createViewDepartmentListRequest();
		viewDepartmentListRequest.setStore(store);
		ViewDepartmentListResponse viewDepartmentListResponse = cnsServiceInterface.viewDepartmentList(viewDepartmentListRequest);
		return viewDepartmentListResponse.getDepartmentDetails();
	}
	public AddDepartmentResponse addDepartment(Department department) {
		AddDepartmentRequest addDepartmentRequest = objectFactory.createAddDepartmentRequest();
		addDepartmentRequest.setDepartment(department);
		AddDepartmentResponse addDepartmentResponse = cnsServiceInterface.addDepartment(addDepartmentRequest);
		return addDepartmentResponse;
	}
	public EditDepartmentResponse editDepartment(Department department) {
		EditDepartmentRequest editDepartmentRequest = objectFactory.createEditDepartmentRequest();
		editDepartmentRequest.setDepartment(department);
		EditDepartmentResponse editDepartmentResponse = cnsServiceInterface.editDepartment(editDepartmentRequest);
		return editDepartmentResponse;
	}
	public RemoveDepartmentResponse removeDepartment(Department department) {
		RemoveDepartmentRequest removeDepartmentRequest = objectFactory.createRemoveDepartmentRequest();
		removeDepartmentRequest.setDepartment(department);
		RemoveDepartmentResponse removeDepartmentResponse = cnsServiceInterface.removeDepartment(removeDepartmentRequest);
		return removeDepartmentResponse;
	}

}
