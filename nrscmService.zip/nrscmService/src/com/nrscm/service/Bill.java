
package com.nrscm.service;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for Bill complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="Bill">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="billId" type="{http://service.nrscm.com/}BillId" minOccurs="0"/>
 *         &lt;element name="billItems" type="{http://service.nrscm.com/}BillItems" minOccurs="0"/>
 *         &lt;element name="discountAvailed" type="{http://service.nrscm.com/}DiscountAvailed" minOccurs="0"/>
 *         &lt;element name="billAmount" type="{http://service.nrscm.com/}BillAmount" minOccurs="0"/>
 *         &lt;element name="oldBillRef" type="{http://service.nrscm.com/}Bill" minOccurs="0"/>
 *         &lt;element name="billDate" type="{http://service.nrscm.com/}BillDate" minOccurs="0"/>
 *         &lt;element name="customerCard" type="{http://service.nrscm.com/}CustomerCard" minOccurs="0"/>
 *         &lt;element name="storeId" type="{http://service.nrscm.com/}StoreId" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "Bill", propOrder = {
    "billId",
    "billItems",
    "discountAvailed",
    "billAmount",
    "oldBillRef",
    "billDate",
    "customerCard",
    "storeId"
})
public class Bill {

    protected Integer billId;
    protected BillItems billItems;
    protected BigDecimal discountAvailed;
    protected BigDecimal billAmount;
    protected Bill oldBillRef;
    protected String billDate;
    protected CustomerCard customerCard;
    protected Integer storeId;

    /**
     * Gets the value of the billId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getBillId() {
        return billId;
    }

    /**
     * Sets the value of the billId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setBillId(Integer value) {
        this.billId = value;
    }

    /**
     * Gets the value of the billItems property.
     * 
     * @return
     *     possible object is
     *     {@link BillItems }
     *     
     */
    public BillItems getBillItems() {
        return billItems;
    }

    /**
     * Sets the value of the billItems property.
     * 
     * @param value
     *     allowed object is
     *     {@link BillItems }
     *     
     */
    public void setBillItems(BillItems value) {
        this.billItems = value;
    }

    /**
     * Gets the value of the discountAvailed property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getDiscountAvailed() {
        return discountAvailed;
    }

    /**
     * Sets the value of the discountAvailed property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setDiscountAvailed(BigDecimal value) {
        this.discountAvailed = value;
    }

    /**
     * Gets the value of the billAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getBillAmount() {
        return billAmount;
    }

    /**
     * Sets the value of the billAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setBillAmount(BigDecimal value) {
        this.billAmount = value;
    }

    /**
     * Gets the value of the oldBillRef property.
     * 
     * @return
     *     possible object is
     *     {@link Bill }
     *     
     */
    public Bill getOldBillRef() {
        return oldBillRef;
    }

    /**
     * Sets the value of the oldBillRef property.
     * 
     * @param value
     *     allowed object is
     *     {@link Bill }
     *     
     */
    public void setOldBillRef(Bill value) {
        this.oldBillRef = value;
    }

    /**
     * Gets the value of the billDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getBillDate() {
        return billDate;
    }

    /**
     * Sets the value of the billDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setBillDate(String value) {
        this.billDate = value;
    }

    /**
     * Gets the value of the customerCard property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerCard }
     *     
     */
    public CustomerCard getCustomerCard() {
        return customerCard;
    }

    /**
     * Sets the value of the customerCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerCard }
     *     
     */
    public void setCustomerCard(CustomerCard value) {
        this.customerCard = value;
    }

    /**
     * Gets the value of the storeId property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getStoreId() {
        return storeId;
    }

    /**
     * Sets the value of the storeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setStoreId(Integer value) {
        this.storeId = value;
    }

}
