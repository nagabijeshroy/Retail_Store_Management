package com.nrscm.service;

import java.math.BigDecimal;
import java.math.MathContext;
import java.sql.ResultSet;

import javax.jws.WebService;

import com.nrscm.service.cps.BillTableDataGateway;
import com.nrscm.service.cps.BillTableModule;
import com.nrscm.service.cps.CustomerCardDataGateway;
import com.nrscm.service.cps.CustomerCardTableModule;
import com.nrscm.service.item.ItemDataGateway;
import com.nrscm.service.item.ItemTableModule;


@WebService(name = "CpsServiceInterface", serviceName = "CpsServiceClient", endpointInterface = "com.nrscm.service.CpsServiceInterface", targetNamespace = "http://service.nrscm.com/", portName = "CpsServicePort", wsdlLocation = "/wsdl/cps.wsdl")
public class CpsService implements CpsServiceInterface {

	@Override
	public GetCardDetailsResponse getCardDetails(GetCardDetailsRequest getCardDetailsRequestMessage) {
		System.out.println("************* getCardDetails");
		System.out.println(getCardDetailsRequestMessage.getCustomerCard().getCardNumber());
		CustomerCard customercard=getCardDetailsRequestMessage.getCustomerCard();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=CustomerCardTableModule.validateForGetCardDetails(customercard, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			CustomerCardDataGateway customercardDataGateway=new CustomerCardDataGateway();
			ResultSet rs=customercardDataGateway.getCardDetails(customercard);
		    customercard=CustomerCardTableModule.mapGetCustomerCardResultSetToCustomerCard(rs);
		}
		GetCardDetailsResponse getCardDetailsResponse=of.createGetCardDetailsResponse();
	    getCardDetailsResponse.setCustomerCard(customercard);
		getCardDetailsResponse.setValidationMessages(validationMessages);
		return getCardDetailsResponse;
	}


	@Override
	public UpdateCardDetailsResponse updateCardDetails(
			UpdateCardDetailsRequest updateCardDetailsRequestMessage) {
		System.out.println("************* updateCardDetails");
		CustomerCard customercard=updateCardDetailsRequestMessage.getCustomerCard();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=CustomerCardTableModule.validateForUpdateCardDetails(customercard, validationMessages);
		CustomerCardDataGateway customerCardDataGateway=new CustomerCardDataGateway();
		return null;  
	}

	@Override
	public GetExistingBillResponse getExistingBill(GetExistingBillRequest getExistingBillRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* getExistingBill");
		Bill bill=getExistingBillRequestMessage.getBill();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=BillTableModule.validateForGetBill(bill, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			BillTableDataGateway billTableDataGateway=new BillTableDataGateway();
			ResultSet billResultSet=billTableDataGateway.getBill(bill);
			bill=BillTableModule.mapGetBillResultSetToBill(billResultSet);
			ResultSet billItemsResultSet=billTableDataGateway.getBillItems(bill);
			BillItems billItems=BillTableModule.mapGetBillItemsResultSetToBillItems(billItemsResultSet);
			bill.setBillItems(billItems);
		}
		GetExistingBillResponse getExistingBillResponse=of.createGetExistingBillResponse();
		getExistingBillResponse.setBill(bill);
		getExistingBillResponse.setValidationMessages(validationMessages);
		return getExistingBillResponse;
	}

	@Override
	public CreateNewBillResponse createNewBill(CreateNewBillRequest createNewBillRequestMessage) {
		// TODO Auto-generated method stub
		Bill bill=createNewBillRequestMessage.getBill();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=BillTableModule.validateForCreateBill(bill, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			// subtract discount value from bill amount if needed
			if(bill.getDiscountAvailed()!=null){
				BigDecimal billAmount=bill.getBillAmount();
				billAmount=billAmount.subtract(bill.getBillAmount().multiply(new BigDecimal(0.1)));
				bill.setBillAmount(billAmount);
			}
			BillTableDataGateway billTableDataGateway=new BillTableDataGateway();
			boolean inserted=billTableDataGateway.createBill(bill);
			// update card details if needed
			boolean updated=false;
			if(inserted&&bill.getCustomerCard()!=null){
				//if(bill.getDiscountAvailed()!=null){
				validationMessages=CustomerCardTableModule.validateForUpdateCardDetails(bill.getCustomerCard(), validationMessages);
				CustomerCardDataGateway customerCardDataGateway=new CustomerCardDataGateway();
				if(validationMessages.getMessages().isEmpty()){
					updated=customerCardDataGateway.updateCardDetails(bill.getCustomerCard());
				}				
				//}
			}
			if(bill.getDiscountAvailed()==null&&inserted){
				for(Item i:bill.getBillItems().getBillItems()){
					validationMessages=ItemTableModule.vaidateForUpdateItemForPOS(i, validationMessages);
					if(validationMessages.getMessages().isEmpty()){
						ItemDataGateway itemDataGateway=new ItemDataGateway();
						boolean itemUpdated=itemDataGateway.updateItem(i);
					}
				}
			}
		}
		// should add code to update items table
		CreateNewBillResponse createNewBillResponse=of.createCreateNewBillResponse();
		createNewBillResponse.setBill(bill);
		createNewBillResponse.setValidationMessages(validationMessages);
		return createNewBillResponse;
	}

}
