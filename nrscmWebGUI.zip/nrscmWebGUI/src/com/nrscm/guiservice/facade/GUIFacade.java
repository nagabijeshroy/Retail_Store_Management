package com.nrscm.guiservice.facade;


import com.nrscm.guiservice.controller.BillController;
import com.nrscm.guiservice.controller.ClearanceControlller;
import com.nrscm.guiservice.controller.CustomerCardController;
import com.nrscm.guiservice.controller.ItemController;
import com.nrscm.guiservice.controller.PromotionController;
import com.nrscm.guiservice.controller.DepartmentController;
import com.nrscm.guiservice.controller.EmployeeController;
import com.nrscm.guiservice.controller.StoreController;
import com.nrscm.service.AddDepartmentResponse;
import com.nrscm.service.AddEmployeeResponse;
import com.nrscm.service.AddStoreResponse;
import com.nrscm.service.DeleteEmployeeResponse;
import com.nrscm.service.Department;
import com.nrscm.service.DepartmentDetails;
import com.nrscm.service.EditDepartmentResponse;
import com.nrscm.service.Employee;
import com.nrscm.service.EmployeeDetails;
import com.nrscm.service.RemoveDepartmentResponse;
import com.nrscm.service.SearchEmployeeResponse;
import com.nrscm.service.Store;
import com.nrscm.service.StoreDetails;
import com.nrscm.service.UpdateEmployeeResponse;
import com.nrscm.service.UpdateStoreResponse;
import com.nrscm.service.ViewEmployeeResponse;



public class GUIFacade {
	
	ItemController itemController=new ItemController();
	BillController billController=new BillController();
	CustomerCardController customerCardController=new CustomerCardController();
	PromotionController promotionController=new PromotionController();
	ClearanceControlller clearanceControlller=new ClearanceControlller();
	
	public String addItem(String jsonItem){
		String addItemResponseJson=itemController.addItem(jsonItem);
		return addItemResponseJson;
	}
	
	public String searchItem(String jsonItem){
		String searchItemResponseJson=itemController.searchItem(jsonItem);
		return searchItemResponseJson;
	}
	
	public String updateItem(String jsonItem){
		String updateItemResponseJson=itemController.updateItem(jsonItem);
		return updateItemResponseJson;
	}
	
	public String deleteItem(String jsonItem){
		String deleteItemResponseJson=itemController.deleteItem(jsonItem);
		return deleteItemResponseJson;
	}
	
	public String getCardDetails(String jsonCard){
		String getCardDetailsJson=customerCardController.getCardDetails(jsonCard);
		return getCardDetailsJson;
	}
	
	/*public String updateCardDetails(String jsonCard){
		String updateCardDetailsJson=customerCardController.updateCardDetails(jsonCard);
		return updateCardDetailsJson;
	}*/
	
	public String getExistingBill(String jsonBill){
		String getExistingBillResponse=billController.getExistingBill(jsonBill);
		return getExistingBillResponse;
	}
	
	public String generateNewBill(String jsonBill){
		String generateNewBillResponse=billController.generateNewBill(jsonBill);
		return generateNewBillResponse;
	}
	
	public String createCustomerCard(String jsonCard){
		String createCustomerCardResponse=customerCardController.createCustomerCard(jsonCard);
		return createCustomerCardResponse;
	}
	
	public String getItemPromotion(String jsonItem){
		String getPromotionForItemResponse=promotionController.getPromotionForItem(jsonItem);
		return getPromotionForItemResponse;
	}
	
	public String getItemClearance(String jsonItem){
		String getClearanceForItemResponse=clearanceControlller.getClearanceForItem(jsonItem);
		return getClearanceForItemResponse;
	}
	
	public String addPromotion(String jsonPromotion){
		String addPromotionResponseJson=promotionController.addPromotion(jsonPromotion);
		return addPromotionResponseJson;
	}
	
	public String updatePromotion(String jsonPromotion){
		String updatePromotionResponseJson=promotionController.updatePromotion(jsonPromotion);
		return updatePromotionResponseJson;
	}
	
	public String removePromotion(String jsonPromotion){
		String removePromotionResponseJson=promotionController.removePromotion(jsonPromotion);
		return removePromotionResponseJson;
	}
	
	public String createClearance(String jsonClearance){
		String createClearanceResponse=clearanceControlller.createClearance(jsonClearance);
		return createClearanceResponse;
	}
	
	StoreController storeController = new StoreController();
	DepartmentController departmentController = new DepartmentController();
	EmployeeController employeeController = new EmployeeController();
	public AddStoreResponse addStoreDetails(Store store) {
		AddStoreResponse addStoreItemResponseJson = storeController.addStoreDetails(store);
		return addStoreItemResponseJson;
	}

	public String authenticateLogin(String jsonItem) {
		String authenticateLogin = storeController.authenticateLogin(jsonItem);
		return authenticateLogin;
	}

	public StoreDetails viewStoreList() {
		StoreDetails storeDetails = storeController.viewStoreList();
		return storeDetails;
	}

	public UpdateStoreResponse updateStore(Store store) {
		UpdateStoreResponse updateStoreResponse  = storeController.updateStoreDetails(store);
		return updateStoreResponse;
	}

	public DepartmentDetails viewDepartmentList(Store store) {
		DepartmentDetails departmentDetails = departmentController.viewDepartmentList(store);
		return departmentDetails;
	}

	public AddEmployeeResponse addEmployee(Employee employee) {
		AddEmployeeResponse employeeResponse = employeeController.addEmployee(employee);
		return employeeResponse;
	}

	public SearchEmployeeResponse searchEmployee(Employee employee) {
		SearchEmployeeResponse searchEmployeeResponse = employeeController.searchEmployee(employee);
		return searchEmployeeResponse;
	}

	public UpdateEmployeeResponse updateEmployee(Employee employee) {
		UpdateEmployeeResponse updateEmployeeResponse = employeeController.updateEmployee(employee);
		return updateEmployeeResponse;
	}

	public DeleteEmployeeResponse deleteEmployee(Employee employee) {
		DeleteEmployeeResponse deleteEmployeeResponse = employeeController.deleteEmployee(employee);
		return deleteEmployeeResponse;
	}

	public AddDepartmentResponse addDepartment(Department department) {
		AddDepartmentResponse addDepartmentResponse = departmentController.addDepartment(department);
		return addDepartmentResponse;
	}

	public EditDepartmentResponse editDepartment(Department department) {
		EditDepartmentResponse editDepartmentResponse = departmentController.editDepartment(department);
		return editDepartmentResponse;
	}

	public RemoveDepartmentResponse removeDepartment(Department department) {
		RemoveDepartmentResponse removeDepartmentResponse = departmentController.removeDepartment(department);
		return removeDepartmentResponse;
	}

	public ViewEmployeeResponse viewEmployee() {
		ViewEmployeeResponse viewEmployeeResponse = employeeController.viewEmployee();
		return viewEmployeeResponse;
	}
	
	

}
