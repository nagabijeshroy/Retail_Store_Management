package com.nrscm.service.TableModule;

import com.nrscm.service.Employee;
import com.nrscm.service.Messages;

public class EmployeeTableModule {

	public static Messages validateEmployeeDetails(Employee employee, Messages messages) {
		Messages messages2 = new Messages();
		messages2.getMessages().add("Success");
		return messages2;
	}

}
