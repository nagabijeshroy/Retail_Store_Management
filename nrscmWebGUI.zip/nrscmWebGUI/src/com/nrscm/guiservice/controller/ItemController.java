package com.nrscm.guiservice.controller;

import com.google.gson.Gson;
import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.CreateItemRequest;
import com.nrscm.service.CreateItemResponse;
import com.nrscm.service.DeleteItemRequest;
import com.nrscm.service.DeleteItemResponse;
import com.nrscm.service.GetItemRequest;
import com.nrscm.service.GetItemResponse;
import com.nrscm.service.GetItemsRequest;
import com.nrscm.service.GetItemsResponse;
import com.nrscm.service.Item;
import com.nrscm.service.ItemServiceInterface;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.UpdateItemRequest;
import com.nrscm.service.UpdateItemResponse;

public class ItemController {
	public String addItem(String jsonItem){
		System.out.println("ItemController "+jsonItem);
		jsonItem=jsonItem.substring(11, jsonItem.length()-1);
		System.out.println("ItemController "+jsonItem);
		Gson gson=new Gson();
		Item item=gson.fromJson(jsonItem, Item.class);
		//CreateItemRequest createItemRequest=gson.fromJson(jsonItem, CreateItemRequest.class);
		//System.out.println(item);
		//System.out.println(item.getId());
		ItemServiceInterface itemServiceInterface=NRSCMClient.getItemServiceInterface();
		ObjectFactory objectFactory=new ObjectFactory();
		CreateItemRequest createItemRequest=objectFactory.createCreateItemRequest();
		createItemRequest.setItem(item);
		CreateItemResponse createItemResponse=itemServiceInterface.createItem(createItemRequest);
		String createItemResponseJson=gson.toJson(createItemResponse);
		return createItemResponseJson;
	}
	
	public String searchItem(String jsonItem){
		System.out.println("ItemController "+jsonItem);
		jsonItem=jsonItem.substring(11, jsonItem.length()-1);
		System.out.println("ItemController "+jsonItem);
		Gson gson=new Gson();
		Item item=gson.fromJson(jsonItem, Item.class);
		//GetItemsRequest getItemsRequest=gson.fromJson(jsonItem, GetItemsRequest.class);
		ItemServiceInterface itemServiceInterface=NRSCMClient.getItemServiceInterface();
		ObjectFactory of=new ObjectFactory();
		GetItemsRequest getItemsRequest=of.createGetItemsRequest();
		getItemsRequest.setItem(item);
		GetItemsResponse getItemsResponse=itemServiceInterface.getItems(getItemsRequest);
		String getItemsResponseJson=gson.toJson(getItemsResponse);
		return getItemsResponseJson;
	}
	
	public String updateItem(String jsonItem){
		System.out.println("ItemController "+jsonItem);
		jsonItem=jsonItem.substring(11, jsonItem.length()-1);
		System.out.println("ItemController "+jsonItem);
		Gson gson=new Gson();
		Item item=gson.fromJson(jsonItem, Item.class);
		//CreateItemRequest createItemRequest=gson.fromJson(jsonItem, CreateItemRequest.class);
		//System.out.println(item);
		//System.out.println(item.getId());
		ItemServiceInterface itemServiceInterface=NRSCMClient.getItemServiceInterface();
		ObjectFactory objectFactory=new ObjectFactory();
		UpdateItemRequest updateItemRequest=objectFactory.createUpdateItemRequest();
		updateItemRequest.setItem(item);
		UpdateItemResponse updateItemResponse=itemServiceInterface.updateItem(updateItemRequest);
		String updateItemResponseJson=gson.toJson(updateItemResponse);
		return updateItemResponseJson;
	}
	
	public String deleteItem(String jsonItem){
		System.out.println("ItemController "+jsonItem);
		jsonItem=jsonItem.substring(11, jsonItem.length()-1);
		System.out.println("ItemController "+jsonItem);
		Gson gson=new Gson();
		Item item=gson.fromJson(jsonItem, Item.class);
		ItemServiceInterface itemServiceInterface=NRSCMClient.getItemServiceInterface();
		ObjectFactory objectFactory=new ObjectFactory();
		DeleteItemRequest deleteItemRequest=objectFactory.createDeleteItemRequest();
		deleteItemRequest.setItem(item);
		DeleteItemResponse deleteItemResponse=itemServiceInterface.deleteItem(deleteItemRequest);
		String deleteItemResponseJson=gson.toJson(deleteItemResponse);
		return deleteItemResponseJson;
	}

}
