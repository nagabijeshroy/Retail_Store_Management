package com.nrscm.service.pc;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.nrscm.service.Clearance;
import com.nrscm.service.Item;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.Promotion;
import com.nrscm.service.Messages;


public class PromotionsTableModule {

	
	public static Messages validateForCreatePromotion(Promotion promotion, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		/*if(promotion.getId()==null){
			validationMessages.add("Need Id for Promotion");
			System.out.println("Need Id for Promotion");
		}*/
		if(promotion.getDiscount()==null){
			validationMessages.add("Need Discount for Promotion");
			System.out.println("Need Discount for Promotion");
		}
		if(promotion.getItemid()==null){
			validationMessages.add("Need Item Id to add Promotion");
			System.out.println("Need Item Id to add Promotion");
		}
	return valMessages;
	}
	

	public static Messages validateForUpdatePromotion(Promotion promotion, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(promotion.getId()==null){
			validationMessages.add("Need Id for Promotion");
			System.out.println("Need Id for Promotion");
		}
		if(promotion.getDiscount()==null){
			validationMessages.add("Need Discount for Promotion");
			System.out.println("Need Discount for Promotion");
		}
	return valMessages;
	}
	
	
	public static Messages vaidateForRemovePromotion(Promotion promotion, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(promotion.getId()==null){
			validationMessages.add("Need id for Promotion");
			System.out.println("Need id for Promotion");
		}
		return valMessages;
	}
	
	public static Messages vaidateForGetPromotionForItem(Item item, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(item.getId()==null){
			validationMessages.add("Need item id");
			System.out.println("Need item id");
		}
		return valMessages;
	}
	
	public static Promotion mapGetPromotionForItemResultSetToPromotion(ResultSet rs){
		ObjectFactory of=new ObjectFactory();
		//Clearance clearance=of.createClearance();
		Promotion promotion=of.createPromotion();
		try {
			if(rs.next()){
				promotion.setDiscount(rs.getBigDecimal("DISCOUNTPERCENT"));
				promotion.setId(rs.getInt("PROMOTION_ID"));
				promotion.setItemid(rs.getInt("ITEM_ID"));
				promotion.setStoreId(rs.getInt("STORE_ID"));
				return promotion;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
}