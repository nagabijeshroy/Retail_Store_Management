package com.nrscm.service;

import java.sql.ResultSet;
import java.sql.SQLException;

import javax.jws.WebService;

import com.nrscm.service.cps.CustomerCardDataGateway;
import com.nrscm.service.cps.CustomerCardTableModule;


@WebService(name = "POSServiceInterface", serviceName = "POSServiceClient", endpointInterface = "com.nrscm.service.POSServiceInterface", targetNamespace = "http://service.nrscm.com/", portName = "POSServicePort", wsdlLocation = "/wsdl/pos.wsdl")
public class POSService implements POSServiceInterface {

	@Override
	public CreateBillResponse createBill(CreateBillRequest createBillRequestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CreateCustomerCardResponse createCustomerCard(CreateCustomerCardRequest createCustomerCardRequestMessage) {
		// TODO Auto-generated method stub
		System.out.println("************* createCustomerCard");
		CustomerCard customerCard=createCustomerCardRequestMessage.getCustomerCard();
		ObjectFactory of=new ObjectFactory();
		Messages validationMessages=of.createMessages();
		validationMessages=CustomerCardTableModule.validateForCreateCustomerCard(customerCard, validationMessages);
		if(validationMessages.getMessages().isEmpty()){
			CustomerCardDataGateway customerCardDataGateway=new CustomerCardDataGateway();
			ResultSet rs=customerCardDataGateway.createCustomerCard(customerCard);
			try {
				if (rs.next()) {
					 int newCustomerCardId = rs.getInt(1);
					 customerCard.setCardNumber(newCustomerCardId);
				 }
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
		CreateCustomerCardResponse createCustomerCardResponse=of.createCreateCustomerCardResponse();
		createCustomerCardResponse.setCustomerCard(customerCard);
		createCustomerCardResponse.setValidationMessages(validationMessages);
		return createCustomerCardResponse;
	}

	@Override
	public SearchBillItemResponse searchBillItem(SearchBillItemRequest searchBillItemRequestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

	// two methods to be included
	//getItemClearance
	//getItemPromotion
	
	@Override
	public UpdateCustomerCardResponse updateCustomerCard(UpdateCustomerCardRequest updateCustomerCardRequestMessage) {
		// TODO Auto-generated method stub
		return null;
	}

}
