package com.nrscm.guiservice.controller;

import com.google.gson.Gson;
import com.nrscm.guiservice.nrscmServiceCaller.NRSCMClient;
import com.nrscm.service.CpsServiceInterface;
import com.nrscm.service.CreateCustomerCardRequest;
import com.nrscm.service.CreateCustomerCardResponse;
import com.nrscm.service.CustomerCard;
import com.nrscm.service.GetCardDetailsRequest;
import com.nrscm.service.GetCardDetailsResponse;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.POSServiceInterface;
import com.nrscm.service.UpdateCardDetailsRequest;
import com.nrscm.service.UpdateCardDetailsResponse;

public class CustomerCardController {
	
	public String getCardDetails(String jsonCard){
		System.out.println("CustomerCardController "+jsonCard);
		jsonCard=jsonCard.substring(19, jsonCard.length()-1);
		System.out.println("CustomerCardController "+jsonCard);
		Gson gson=new Gson();
		CustomerCard customerCard=gson.fromJson(jsonCard, CustomerCard.class);
		CpsServiceInterface cpsServiceInterface=NRSCMClient.getCpsServiceInterface();
		ObjectFactory objectFactory=new ObjectFactory();
		GetCardDetailsRequest getCardDetailsRequest=objectFactory.createGetCardDetailsRequest();
		getCardDetailsRequest.setCustomerCard(customerCard);
		GetCardDetailsResponse getCardDetailsResponse=cpsServiceInterface.getCardDetails(getCardDetailsRequest);
		String getCardDetailsResponseJson=gson.toJson(getCardDetailsResponse);
		return getCardDetailsResponseJson;
	}
	
	/*public String updateCardDetails(String jsonCard){
		System.out.println("CustomerCardController "+jsonCard);
		jsonCard=jsonCard.substring(19, jsonCard.length()-1);
		System.out.println("CustomerCardController "+jsonCard);
		Gson gson=new Gson();
		CustomerCard customerCard=gson.fromJson(jsonCard, CustomerCard.class);
		CpsServiceInterface cpsServiceInterface=NRSCMClient.getCpsServiceInterface();
		ObjectFactory objectFactory=new ObjectFactory();
		UpdateCardDetailsRequest updateCardDetailsRequest=objectFactory.createUpdateCardDetailsRequest();
		updateCardDetailsRequest.setCustomerCard(customerCard);
		UpdateCardDetailsResponse updateCardDetailsResponse=cpsServiceInterface.updateCardDetails(updateCardDetailsRequest);
		String updateCardDetailsResponseJson=gson.toJson(updateCardDetailsResponse);
		return updateCardDetailsResponseJson;
	}*/
	
	public String createCustomerCard(String jsonCard){
		System.out.println("CustomerCardController "+jsonCard);
		jsonCard=jsonCard.substring(19, jsonCard.length()-1);
		System.out.println("CustomerCardController "+jsonCard);
		Gson gson=new Gson();
		CustomerCard customerCard=gson.fromJson(jsonCard, CustomerCard.class);
		POSServiceInterface posServiceInterface=NRSCMClient.getPosServiceInterface();
		ObjectFactory of=new ObjectFactory();
		CreateCustomerCardRequest createCustomerCardRequest=of.createCreateCustomerCardRequest();
		createCustomerCardRequest.setCustomerCard(customerCard);
		CreateCustomerCardResponse createCustomerCardResponse=posServiceInterface.createCustomerCard(createCustomerCardRequest);
		String createCustomerCardResponseJson=gson.toJson(createCustomerCardResponse);
		return createCustomerCardResponseJson;
	}

}
