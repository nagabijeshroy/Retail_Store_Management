package com.nrscm.guiservice.nrscmServiceCaller;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import javax.xml.ws.BindingProvider;

import com.nrscm.service.CNSServiceClient;
import com.nrscm.service.CNSServiceInterface;
import com.nrscm.service.CpsServiceClient;
import com.nrscm.service.CpsServiceInterface;
import com.nrscm.service.ItemServiceClient;
import com.nrscm.service.ItemServiceInterface;
import com.nrscm.service.PCServiceClient;
import com.nrscm.service.PCServiceInterface;
import com.nrscm.service.POSServiceClient;
import com.nrscm.service.POSServiceInterface;

public class NRSCMClient {
	
	private static NRSCMClient client=new NRSCMClient();
	private static ItemServiceInterface itemServiceInterface;
	private static CpsServiceInterface cpsServiceInterface;
	private static POSServiceInterface posServiceInterface;
	private static PCServiceInterface pcServiceInterface;
	private static CNSServiceInterface cnsServiceInterface;
	
	private NRSCMClient(){
		ItemServiceClient itemServiceClient=null;
		CpsServiceClient cpsServiceClient=null;
		POSServiceClient posServiceClient=null;
		PCServiceClient pcServiceClient=null;
		CNSServiceClient cnsServiceClient=null;
		try{
			// add wsdl file to GUI project and use those urls?
			itemServiceClient=new ItemServiceClient(new URL("http://localhost:8083/nrscmService/wsdl/item.wsdl"));
			cpsServiceClient=new CpsServiceClient(new URL("http://localhost:8083/nrscmService/wsdl/cps.wsdl"));
			posServiceClient=new POSServiceClient(new URL("http://localhost:8083/nrscmService/wsdl/pos.wsdl"));
			pcServiceClient=new PCServiceClient(new URL("http://localhost:8083/nrscmService/wsdl/pc.wsdl"));
			cnsServiceClient=new CNSServiceClient(new URL("http://localhost:8083/nrscmService/wsdl/CNS.wsdl"));
		}catch(MalformedURLException e){
			System.out.println("Please provide correct WSDL URL");
			e.printStackTrace();
		}
		itemServiceInterface=itemServiceClient.getItemServicePort();
		Map<String, Object> ctxti = ((BindingProvider)itemServiceInterface ).getRequestContext();
		ctxti.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://localhost:8083/nrscmService/ItemServiceClient");
		cpsServiceInterface=cpsServiceClient.getCpsServicePort();
		Map<String, Object> ctxtcps = ((BindingProvider)cpsServiceInterface ).getRequestContext();
		ctxtcps.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://localhost:8083/nrscmService/CpsServiceClient");
		posServiceInterface=posServiceClient.getPOSServicePort();
		Map<String, Object> ctxtpos = ((BindingProvider)posServiceInterface ).getRequestContext();
		ctxtpos.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://localhost:8083/nrscmService/POSServiceClient");
		pcServiceInterface=pcServiceClient.getPCServicePort();
		Map<String, Object> ctxtpc = ((BindingProvider)pcServiceInterface ).getRequestContext();
		ctxtpc.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://localhost:8083/nrscmService/PCServiceClient");
		cnsServiceInterface=cnsServiceClient.getCNSServicePort();
		Map<String, Object> ctxtcns = ((BindingProvider)cnsServiceInterface ).getRequestContext();
		ctxtcns.put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, "http://localhost:8083/nrscmService/CNSServiceClient");
	}
	
	public static ItemServiceInterface getItemServiceInterface(){
		return itemServiceInterface;
	}
	
	public static CpsServiceInterface getCpsServiceInterface(){
		return cpsServiceInterface;
	}
	
	public static POSServiceInterface getPosServiceInterface(){
		return posServiceInterface;
	}
	
	public static PCServiceInterface getPCServiceInterface(){
		return pcServiceInterface;
	}
	
	public static CNSServiceInterface getCNSServiceInterface(){
		return cnsServiceInterface;
	}
}
	
