package com.nrscm.service;

import javax.jws.WebService;

import com.nrscm.service.AddDepartmentRequest;
import com.nrscm.service.AddDepartmentResponse;
import com.nrscm.service.AddEmployeeRequest;
import com.nrscm.service.AddEmployeeResponse;
import com.nrscm.service.AddStoreRequest;
import com.nrscm.service.AddStoreResponse;
import com.nrscm.service.CNSServiceInterface;
import com.nrscm.service.DeleteEmployeeRequest;
import com.nrscm.service.DeleteEmployeeResponse;
import com.nrscm.service.Department;
import com.nrscm.service.DepartmentDetails;
import com.nrscm.service.EditDepartmentRequest;
import com.nrscm.service.EditDepartmentResponse;
import com.nrscm.service.Employee;
import com.nrscm.service.EmployeeDetails;
import com.nrscm.service.Messages;
import com.nrscm.service.ObjectFactory;
import com.nrscm.service.RemoveDepartmentRequest;
import com.nrscm.service.RemoveDepartmentResponse;
import com.nrscm.service.SearchEmployeeRequest;
import com.nrscm.service.SearchEmployeeResponse;
import com.nrscm.service.Store;
import com.nrscm.service.StoreDetails;
import com.nrscm.service.UpdateEmployeeRequest;
import com.nrscm.service.UpdateEmployeeResponse;
import com.nrscm.service.UpdateStoreRequest;
import com.nrscm.service.UpdateStoreResponse;
import com.nrscm.service.ViewDepartmentListRequest;
import com.nrscm.service.ViewDepartmentListResponse;
import com.nrscm.service.ViewEmployeeRequest;
import com.nrscm.service.ViewEmployeeResponse;
import com.nrscm.service.ViewStoreListRequest;
import com.nrscm.service.ViewStoreListResponse;
import com.nrscm.service.DataGateway.DepartmentDataGateway;
import com.nrscm.service.DataGateway.EmployeeDataGateway;
import com.nrscm.service.DataGateway.StoreDataGateWay;
import com.nrscm.service.TableModule.DepartmentTableModule;
import com.nrscm.service.TableModule.EmployeeTableModule;
import com.nrscm.service.TableModule.StoreTableModule;

@WebService(name = "CNSServiceInterface", serviceName = "CNSServiceClient", endpointInterface = "com.nrscm.service.CNSServiceInterface", targetNamespace = "http://service.nrscm.com/", portName = "CNSServicePort", wsdlLocation = "/wsdl/CNS.wsdl")
public class CNSSerivceImpl implements CNSServiceInterface {
	Store store = new Store();
	Department department = new Department();
	Employee employee = new Employee();
	ObjectFactory objectFactory = new ObjectFactory();

	@Override
	public AddStoreResponse addStoreDetails(AddStoreRequest addStoreRequestMessage) {
		Boolean isAdded = false;
		store = addStoreRequestMessage.getStore();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = StoreTableModule.validateStoreDetails(store, messages);
		StoreDataGateWay storeDataGateWay = new StoreDataGateWay();
		isAdded = storeDataGateWay.addStore(store);
		AddStoreResponse addStoreResponse = objectFactory.createAddStoreResponse();
		if (isAdded == true) {
			messages.getMessages().add("Store has been successfully added");
		} else {
			messages.getMessages().add("Problem with adding the store");
		}
		addStoreResponse.setValidationMessages(messages);
		return addStoreResponse;
	}

	@Override
	public ViewEmployeeResponse viewEmployee(ViewEmployeeRequest viewEmployeeRequestMessage) {
		Messages messages = objectFactory.createMessages();
		messages = EmployeeTableModule.validateEmployeeDetails(employee, messages);
		EmployeeDataGateway employeeDataGateway = new EmployeeDataGateway();
		EmployeeDetails employeeDetails = employeeDataGateway.viewEmployee();
		ViewEmployeeResponse employeeResponse = objectFactory.createViewEmployeeResponse();
		if (employee != null) {
			employeeResponse.setEmployeeDetails(employeeDetails);
			messages.getMessages().add("Success");
			employeeResponse.setValidationMessages(messages);
		} else {
			messages.getMessages().add("Failure");
			employeeResponse.setValidationMessages(messages);
		}
		return employeeResponse;
	}

	@Override
	public UpdateEmployeeResponse updateEmployee(UpdateEmployeeRequest updateEmployeeRequestMessage) {
		Messages messages = objectFactory.createMessages();
		messages = EmployeeTableModule.validateEmployeeDetails(employee, messages);
		EmployeeDataGateway employeeDataGateway = new EmployeeDataGateway();
		employee = employeeDataGateway.updateEmployee(updateEmployeeRequestMessage.getEmployee());
		UpdateEmployeeResponse employeeResponse = objectFactory.createUpdateEmployeeResponse();
		if (employee != null) {
			employeeResponse.setEmployee(employee);
			messages.getMessages().add("Success");
			employeeResponse.setValidationMessages(messages);
		} else {
			messages.getMessages().add("Failure");
			employeeResponse.setValidationMessages(messages);
		}
		return employeeResponse;
	}

	@Override
	public RemoveDepartmentResponse removeDepartment(RemoveDepartmentRequest removeDepartmentRequestMessage) {
		Messages messages = objectFactory.createMessages();
		messages = DepartmentTableModule.validateDepartmentDetails(department, messages);
		DepartmentDataGateway departmentDataGateway = new DepartmentDataGateway();
		messages.getMessages().add(departmentDataGateway.removeDepartment(removeDepartmentRequestMessage.getDepartment()));
		RemoveDepartmentResponse departmentResponse = objectFactory.createRemoveDepartmentResponse();
		departmentResponse.setValidationMessages(messages);
		return departmentResponse;
	}

	@Override
	public UpdateStoreResponse updateStore(UpdateStoreRequest updateStoreRequestMessage) {
		Boolean isUpdated = false;
		store = updateStoreRequestMessage.getStore();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = StoreTableModule.validateStoreDetails(store, messages);
		StoreDataGateWay storeDataGateWay = new StoreDataGateWay();
		isUpdated = storeDataGateWay.updateStore(store);
		UpdateStoreResponse updateStoreResponse = objectFactory.createUpdateStoreResponse();
		if (isUpdated == true) {
			messages.getMessages().add("Store has been successfully updates");
		} else {
			messages.getMessages().add("Problem with updating the store");
		}
		updateStoreResponse.setValidationMessages(messages);
		return updateStoreResponse;
	}

	@Override
	public EditDepartmentResponse editDepartment(EditDepartmentRequest editDepartmentRequestMessage) {
		Boolean isUpdated = false;
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = DepartmentTableModule.validateDepartmentDetails(department, messages);
		DepartmentDataGateway departmentDataGateway = new DepartmentDataGateway();
		isUpdated = departmentDataGateway.editDepartment(editDepartmentRequestMessage.getDepartment());
		EditDepartmentResponse editDepartmentResponse = objectFactory.createEditDepartmentResponse();
		if (isUpdated == true) {
			messages.getMessages().add("Department has been successfully updated");
		} else {
			messages.getMessages().add("Problem with updating the Department");
		}
		editDepartmentResponse.setValidationMessages(messages);
		return editDepartmentResponse;
	}

	@Override
	public AddDepartmentResponse addDepartment(AddDepartmentRequest addDepartmentRequestMessage) {
		Boolean isAdded = false;
		department = addDepartmentRequestMessage.getDepartment();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = DepartmentTableModule.validateDepartmentDetails(department, messages);
		DepartmentDataGateway departmentDataGateway = new DepartmentDataGateway();
		isAdded = departmentDataGateway.addDepartment(department);
		AddDepartmentResponse addDepartmentResponse = objectFactory.createAddDepartmentResponse();
		if (isAdded == true) {
			messages.getMessages().add("Department has been successfully added");
		} else {
			messages.getMessages().add("Problem with adding the Department");
		}
		addDepartmentResponse.setValidationMessages(messages);
		return addDepartmentResponse;
	}

	@Override
	public SearchEmployeeResponse searchEmployee(SearchEmployeeRequest searchEmployeeRequestMessage) {
		employee = searchEmployeeRequestMessage.getEmployee();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = EmployeeTableModule.validateEmployeeDetails(employee, messages);
		EmployeeDataGateway employeeDataGateway = new EmployeeDataGateway();
		employee = employeeDataGateway.searchEmployee(employee);
		SearchEmployeeResponse searchEmployeeResponse = objectFactory.createSearchEmployeeResponse();
		if(employee!=null){
		searchEmployeeResponse.setEmployee(employee);
		messages.getMessages().add("Employee has been found");
		}else{
			messages.getMessages().add("Problem with finding the Employee");	
		}
		searchEmployeeResponse.setValidationMessages(messages);
		return searchEmployeeResponse;
	}

	@Override
	public DeleteEmployeeResponse deleteEmployee(DeleteEmployeeRequest deleteEmployeeRequestMessage) {
		Boolean isDeleted = false;
		employee = deleteEmployeeRequestMessage.getEmployee();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = EmployeeTableModule.validateEmployeeDetails(employee, messages);
		EmployeeDataGateway employeeDataGateway = new EmployeeDataGateway();
		isDeleted = employeeDataGateway.deleteEmployee(employee);
		DeleteEmployeeResponse deleteEmployeeResponse = objectFactory.createDeleteEmployeeResponse();
		if (isDeleted == true) {
			messages.getMessages().add("Employee has been deleted");
		} else {
			messages.getMessages().add("Problem with deleting the Employee");
		}
		deleteEmployeeResponse.setValidationMessages(messages);
		return deleteEmployeeResponse;
	}

	@Override
	public AddEmployeeResponse addEmployee(AddEmployeeRequest addEmployeeRequestMessage) {
		Boolean isAdded = false;
		employee = addEmployeeRequestMessage.getEmployee();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = EmployeeTableModule.validateEmployeeDetails(employee, messages);
		EmployeeDataGateway employeeDataGateway = new EmployeeDataGateway();
		isAdded = employeeDataGateway.addEmployee(employee);
		AddEmployeeResponse addEmployeeResponse = objectFactory.createAddEmployeeResponse();
		if (isAdded == true) {
			messages.getMessages().add("Employee has been added");
		} else {
			messages.getMessages().add("Problem with adding the Employee");
		}
		addEmployeeResponse.setValidationMessages(messages);
		return addEmployeeResponse;
	}

	@Override
	public ViewStoreListResponse viewStoreList(ViewStoreListRequest viewStoreListRequestMessage) {
		StoreDetails storeDetails = new StoreDetails();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = StoreTableModule.validateStoreDetails(store, messages);
		StoreDataGateWay storeDataGateWay = new StoreDataGateWay();
		storeDetails = storeDataGateWay.viewStoreList();
		ViewStoreListResponse viewStoreListResponse = objectFactory.createViewStoreListResponse();
		viewStoreListResponse.setStoreDetails(storeDetails);
		return viewStoreListResponse;
	}

	@Override
	public ViewDepartmentListResponse viewDepartmentList(ViewDepartmentListRequest viewDepartmentListRequestMessage) {
		DepartmentDetails departmentDetails = new DepartmentDetails();
		Messages messages = objectFactory.createMessages();
		System.out.println("In service impl");
		messages = DepartmentTableModule.validateDepartmentDetails(department, messages);
		Department department = new Department();
		department.setStoreId(viewDepartmentListRequestMessage.getStore().getStoreId());
		DepartmentDataGateway departmentDataGateway = new DepartmentDataGateway();
		departmentDetails = departmentDataGateway.viewDepartmentList(department);
		ViewDepartmentListResponse viewDepartmentListResponse = objectFactory.createViewDepartmentListResponse();
		viewDepartmentListResponse.setDepartmentDetails(departmentDetails);
		return viewDepartmentListResponse;
	}

}
