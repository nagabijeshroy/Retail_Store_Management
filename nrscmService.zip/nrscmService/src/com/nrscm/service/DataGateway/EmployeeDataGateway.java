package com.nrscm.service.DataGateway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nrscm.service.Employee;
import com.nrscm.service.EmployeeDetails;
import com.nrscm.service.Utility.JDBCHelper;

public class EmployeeDataGateway {
	Connection connection = JDBCHelper.connect();
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public Employee updateEmployee(Employee employee) {
		try {
			String query = "update employee set employee_name = ? , employee_address = ? , employee_designation = ? , store_id = ? where employee_id = ? ";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, employee.getName());
			pstmt.setString(2, employee.getEmployeeAddress());
			pstmt.setString(3, employee.getEmployeeDesgnation());
			pstmt.setInt(4, employee.getStoreId());
			pstmt.setInt(5, employee.getEid());
			System.out.println(query + "pstmt: ");
			pstmt.executeUpdate();
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return employee;
	}

	public Employee searchEmployee(Employee employee) {
		Employee employee2 = new Employee();
		try {
			String query = "select * from employee where employee_id = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setInt(1, employee.getEid());
			rs = pstmt.executeQuery();
			
			System.out.println(query);
			while (rs.next()) {
				employee2.setEid(Integer.parseInt(rs.getString("employee_id")));
				employee2.setEmployeeAddress(rs.getString("employee_address"));
				employee2.setEmployeeDesgnation(rs.getString("employee_designation"));
				employee2.setStoreId(Integer.parseInt(rs.getString("store_id")));
				employee2.setName(rs.getString("employee_name"));
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return employee2;
	}

	public EmployeeDetails viewEmployee() {
		EmployeeDetails employeeDetails = new EmployeeDetails();
		try {
			String query = "select * from employee where employee_designation = 'Department Head' or employee_designation = 'Store Head'";
			pstmt = connection.prepareStatement(query);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				Employee employee = new Employee();
				employee.setEid(Integer.parseInt(rs.getString("employee_id")));
				employee.setEmployeeAddress(rs.getString("employee_address"));
				employee.setEmployeeDesgnation(rs.getString("employee_designation"));
				employee.setStoreId(Integer.parseInt(rs.getString("store_id")));
				employee.setName(rs.getString("employee_name"));
				employeeDetails.getEmployeeDetails().add(employee);
			}
			System.out.println(query);
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		for (Employee employee2 : employeeDetails.getEmployeeDetails()) {
			System.out.println(employee2.getName()+""+employee2.getEid());
		}
		return employeeDetails;
	}

	public Boolean deleteEmployee(Employee employee) {
		Boolean result = false;
		try {
			String query = "delete from employee where employee_id = ? ";
			pstmt = connection.prepareStatement(query);
			pstmt.setInt(1, employee.getEid());
			System.out.println(query + "pstmt: ");
			if (pstmt.executeUpdate() != 0) {
				result = true;
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	public Boolean addEmployee(Employee employee) {
		Boolean result = false;
		try {
			String query = "insert into employee (employee_name , employee_address, employee_designation, store_id ) values (?,?,?,?) ";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, employee.getName());
			pstmt.setString(2, employee.getEmployeeAddress());
			pstmt.setString(3, employee.getEmployeeDesgnation());
			pstmt.setInt(4, employee.getStoreId());
			System.out.println(query + "pstmt: ");
			if (pstmt.execute() != false) {
				result = true;
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;	}

}
