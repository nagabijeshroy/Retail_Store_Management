package com.nrscm.service.DataGateway;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.nrscm.service.Store;
import com.nrscm.service.StoreDetails;
import com.nrscm.service.Utility.JDBCHelper;

public class StoreDataGateWay {
	Connection connection = JDBCHelper.connect();
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public Boolean addStore(Store store) {
		Boolean result = false;
		try {
			String query = "insert into store(store_name,store_location) values (?,?)";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, store.getStoreName());
			pstmt.setString(2, store.getLocation());
			System.out.println(query + "pstmt: ");
			if (pstmt.execute() != false) {
				result = true;
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	public Boolean updateStore(Store store) {
		Boolean result = false;
		try {
			String query = "update store set store_name = ? , store_location = ? , store_head = ? where store_id = ?";
			pstmt = connection.prepareStatement(query);
			pstmt.setString(1, store.getStoreName());
			pstmt.setString(2, store.getLocation());
			pstmt.setString(3, store.getStoreHead());
			pstmt.setInt(4, store.getStoreId());
			System.out.println(query + "pstmt: ");
			if (pstmt.executeUpdate() != 0) {
				result = true;
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return result;
	}

	public StoreDetails viewStoreList() {
		StoreDetails storeDetails = new StoreDetails();
		Store store;
		try {
			String query = "select * from store";
			pstmt = connection.prepareStatement(query);
			System.out.println(query + "pstmt: ");
			rs = pstmt.executeQuery();
			while(rs.next()){
			store = new Store();
			store.setLocation(rs.getString("store_location"));
			store.setStoreHead(rs.getString("store_head"));
			store.setStoreName(rs.getString("store_name"));
			store.setStoreId(rs.getInt("store_id"));
			storeDetails.getStoreDetails().add(store);
			}
		} catch (SQLException e) {
			System.out.println("DataBase Error");
			e.printStackTrace();
		} finally {
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}

		}
		return storeDetails;
	}

}
