
package com.nrscm.service;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for UpdateCustomerCardResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="UpdateCustomerCardResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="customerCard" type="{http://service.nrscm.com/}CustomerCard"/>
 *         &lt;element name="validationMessages" type="{http://service.nrscm.com/}Messages"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "UpdateCustomerCardResponse", propOrder = {
    "customerCard",
    "validationMessages"
})
public class UpdateCustomerCardResponse {

    @XmlElement(required = true)
    protected CustomerCard customerCard;
    @XmlElement(required = true)
    protected Messages validationMessages;

    /**
     * Gets the value of the customerCard property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerCard }
     *     
     */
    public CustomerCard getCustomerCard() {
        return customerCard;
    }

    /**
     * Sets the value of the customerCard property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerCard }
     *     
     */
    public void setCustomerCard(CustomerCard value) {
        this.customerCard = value;
    }

    /**
     * Gets the value of the validationMessages property.
     * 
     * @return
     *     possible object is
     *     {@link Messages }
     *     
     */
    public Messages getValidationMessages() {
        return validationMessages;
    }

    /**
     * Sets the value of the validationMessages property.
     * 
     * @param value
     *     allowed object is
     *     {@link Messages }
     *     
     */
    public void setValidationMessages(Messages value) {
        this.validationMessages = value;
    }

}
