package com.nrscm.service.pc;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.nrscm.service.Clearance;
import com.nrscm.service.Department;
import com.nrscm.service.Employee;
import com.nrscm.service.Item;
import com.nrscm.service.Messages;
import com.nrscm.service.ObjectFactory;


public class ClearanceTableModule {

	
	public static Messages validateForCreateClearance(Clearance clearance, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		/*if(clearance.getId()==null){
			validationMessages.add("Need Id for Clearance");
			System.out.println("Need Id for Clearance");
		}*/
		if(clearance.getName()==null){
			validationMessages.add("Need Name for Clearance");
			System.out.println("Need Name for Clearance");
		}
		if(clearance.getDiscount()==null){
			validationMessages.add("Need Discount for Clearance");
			System.out.println("Need Discount for Clearance");
		}
	return valMessages;
	}
	

	public static Messages validateForUpdateClearance(Clearance clearance, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(clearance.getId()==null){
			validationMessages.add("Need Id for Clearance");
			System.out.println("Need Id for Clearance");
		}
		if(clearance.getName()==null){
			validationMessages.add("Need Name for Clearance");
			System.out.println("Need Name for Clearance");
		}
		if(clearance.getDiscount()==null){
			validationMessages.add("Need Discount for Clearance");
			System.out.println("Need Discount for Clearance");
		}
	return valMessages;
	}
	
	
	public static Messages vaidateForRemoveClearance(Clearance clearance, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(clearance.getId()==null){
			validationMessages.add("Need id for Clearance");
			System.out.println("Need id for Clearance");
		}
		return valMessages;
	}
	
	public static Messages vaidateForGetClearanceForItem(Item item, Messages valMessages){
		List<String> validationMessages=valMessages.getMessages();
		if(item.getId()==null){
			validationMessages.add("Need item id");
			System.out.println("Need item id");
		}
		return valMessages;
	}
	
	public static Clearance mapGetClearanceForItemResultSetToClearance(ResultSet rs){
		ObjectFactory of=new ObjectFactory();
		Clearance clearance=of.createClearance();
		try {
			if(rs.next()){
				clearance.setDiscount(rs.getBigDecimal("CLEARANCE_DISCOUNT"));
				clearance.setId(rs.getInt("CLEARANCE_ID"));
				clearance.setName(rs.getString("CLEARANCE_NAME"));
				clearance.setStoreId(rs.getInt("STORE_ID"));
				return clearance;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
		
	}
	
}
